<?php
namespace AUBU;
defined('ABSPATH') or die('Prevent direct access!');

use WP_Rest_Request;
use AUBU\DB_Table;
use AUBU\JWT_Token;
use Firebase\JWT\JWT;

class Mail {

  /**
    * Send email to pending user
    * @access public
    * @static
    * @param int $id
    * @param DB_Table $db_table
  */
  public static function to_pending_user( $id, DB_Table $db_table ) {

    $pedning_user_info = $db_table->get_pending_user_by_id($id, 'username,email,first_name,ref_user_id');

    $username = $pedning_user_info->username;
    $email_address = $pedning_user_info->email;
    $first_name = $pedning_user_info->first_name;
    $ref_user_id = $pedning_user_info->ref_user_id;

    if(!empty($email_address)) {

      $ref_user = $db_table->get_ref_user( $ref_user_id );

      $reqested_by = $ref_user['username'] . ' ' . '(' . $ref_user['email'] . ')';

      $subject = __( 'Login ZIV craft rules - Request', 'adding-user-by-user' );

      $url = site_url( '/aubu-set-password?token=' . JWT_Token::get_jwt( $id, $ref_user_id ) );

      $html = sprintf('<h2>%1$s, %2$s</h2>', __('Hello and good afternoon', 'adding-user-by-user'), $first_name);

      $html .= sprintf('<h4>%1$s %2$s</h4>', __('You are asked to register by', 'adding-user-by-user'), $reqested_by);

      $html .= sprintf('<h4> %1$s: %2$s</h4>', __( 'Your username is', 'adding-user-by-user'), $username);

      $html .= sprintf('<p>%s</p>', __('Please click the link or copy and paste it into your preferred browser.', 'adding-user-by-user') );

      $html .= '<a style="max-width: 100%;word-break: break-all;" href="' . $url . '">' . $url . '</a>';

      $html .= sprintf('<p>%s</p>', __('Many Thanks.', 'adding-user-by-user') );

      wp_mail($email_address, $subject, $html );

    }

  }

  /**
    * Send email to Reference User
    * @access public
    * @static
    * @param int $id
    * @param DB_Table $db_table
  */
  public static function to_ref_user( $id, DB_Table $db_table ) {
    $ref_user = $db_table->get_ref_user($id);
    $email_address = $ref_user['email'];
    $username = $ref_user['username'];

    if(!empty($email_address)) {

      $subject = __( 'Login ZIV craft rules - Approval', 'adding-user-by-user' );

      $html = sprintf('<h2>%1$s, %2$s</h2>', __('Hello and good afternoon', 'adding-user-by-user'), $username);

      $html .= sprintf('<h4>%s</h4>', __('Welcome! Your login has been approved by the administrator.', 'adding-user-by-user'));

      $html .= sprintf('<p>%s</p>', __('Many Thanks.', 'adding-user-by-user') );

      wp_mail($email_address, $subject, $html );
    }
  }

  /**
    * Send email to Reference User
    * @access public
    * @static
    * @param int $id - ID of pending user
  */
  public static function to_admin( $id, DB_Table $db_table ) {


    $email_address = get_bloginfo('admin_email');

    if( !empty( $email_address ) ) {

      $pedning_user_info = $db_table->get_pending_user_by_id($id, 'username,email,ref_user_id');

      $ref_user_info = $db_table->get_ref_user( $pedning_user_info->ref_user_id );

      $subject = __('A new user has been created.', 'adding-user-by-user');

      $html = sprintf('<h4>%s </h4>', __('New user information:', 'adding-user-by-user') );

      $html .= sprintf('<p>%s <strong>%s</strong></p>', __('Username:', 'adding-user-by-user'), $pedning_user_info->username );

      $html .= sprintf('<p>%s <strong>%s</strong></p>', __('Email Address:', 'adding-user-by-user'), $pedning_user_info->email );

      $html .= sprintf('<h4>%s </h4>', __('Created by:', 'adding-user-by-user') );

      $html .= sprintf('<p>%s <strong>%s</strong></p>', __('Username:', 'adding-user-by-user'), $ref_user_info['username'] );

      $html .= sprintf('<p>%s <strong>%s</strong></p>', __('Name:', 'adding-user-by-user'), $ref_user_info['name'] );

      $html .= sprintf('<p>%s <strong>%s</strong></p>', __('Email Address:', 'adding-user-by-user'), $ref_user_info['email'] );

      wp_mail($email_address, $subject, $html );

    }

  }

}
