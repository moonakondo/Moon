<?php
namespace AUBU;

defined('ABSPATH') or die('Prevent direct access!');

class Verify_Input {

  public static function is_valid_password($password, $confirm_password) {
    if( empty($password) || empty($confirm_password) ) return false;
    if( $password !== $confirm_password ) return false;

    return true;
  }

}
