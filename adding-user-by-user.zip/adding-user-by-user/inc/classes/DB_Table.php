<?php
namespace AUBU;

class DB_Table {
  private $table_name;
  private $charset_collate;

  public function __construct() {
    global $wpdb;
    $this->db = $wpdb;
    $this->table_name = $this->db->prefix . 'aubu_data';
    $this->charset_collate = $this->db->get_charset_collate();
  }

  public function create_pending_user_table() {

    $sql = <<<QUERY
             CREATE TABLE {$this->table_name} (
               id mediumint(9) NOT NULL AUTO_INCREMENT,
               ref_user_id mediumint(9) NOT NULL,
               username varchar(100) NOT NULL,
               salutation varchar(10),
               first_name varchar(50),
               surname varchar(50),
               email varchar(100) NOT NULL,
               guild varchar(50),
               street varchar(150),
               house_no varchar(150),
               postcode mediumint(9),
               city varchar(50),
               phone varchar(20),
               is_pending BOOLEAN,
               role varchar(30),
               PRIMARY KEY (id)
             ) {$this->charset_collate}
QUERY;

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta( $sql );

    // tracking version
    add_option( AUBU_PLUGIN['name'] . '_version', AUBU_PLUGIN['version'] );

  }

  public function insert_pending_user_data($data) {

    $ref_user_id = trim( esc_sql( $data[ 'ref_user_id' ] ) );
    $user_name = trim( esc_sql( $data[ 'username' ] ) );

    $insert = $this->db->insert($this->table_name, [
      'ref_user_id' => $ref_user_id,
      'username'    => $user_name,
      'salutation'  => trim( esc_sql( $data[ 'salutation' ] ) ),
      'first_name'  => trim( esc_sql( $data[ 'first_name' ] ) ),
      'surname'     => trim( esc_sql( $data[ 'surname' ] ) ),
      'email'       => trim( esc_sql( $data[ 'email' ] ) ),
      'guild'       => trim( esc_sql( $data[ 'guild' ] ) ),
      'street'      => trim( esc_sql( $data[ 'street' ] ) ),
      'house_no'    => trim( esc_sql( $data[ 'house_no' ] ) ),
      'postcode'    => trim( esc_sql( $data[ 'postcode' ] ) ),
      'city'        => trim( esc_sql( $data[ 'city' ] ) ),
      'phone'       => trim( esc_sql( $data[ 'phone' ] ) ),
      'is_pending'  => true,
      'role'  => trim( esc_sql( $data[ 'role' ] ) ),
    ]);
    $sql = "SELECT id, username, email FROM {$this->table_name} WHERE id={$this->db->insert_id}";

    add_user_meta( $ref_user_id, AUBU_KEY_CREATED_USERS_INFO, array(
      'user_name'      => $user_name,
      'creation_date'  => date('F d, Y')
    ) );

    return $this->db->get_results($sql);
  }

  // get pending user data
  public function get_all_pending_users( $per_page = 10, $page_number = 1, $is_pending = true ) {

    $sql = "SELECT * FROM {$this->table_name} WHERE is_pending='{$is_pending}'";

    if( !empty( $_REQUEST['orderby'] ) ) {
      $sql .= ' ORDER BY ' . esc_sql( $_REQUEST['orderby'] );
      $sql .= !empty( $_REQUEST['order'] ) ? ' ' . esc_sql( $_REQUEST['order'] ) : ' ASC';
    }

    $sql .= " LIMIT {$per_page}";

    $sql .= ' OFFSET ' . ( $page_number - 1 ) * $per_page;

    $result = $this->db->get_results( $sql, 'ARRAY_A' );

    return $result;
  }

  /**
   * Delete a pending user record
   * @param int $id pending user id
  */

  public function delete_pending_user( $id ) {
    $this->db->delete( $this->table_name, array( 'id' => $id ), array( '%d' ) );
  }


  /**
   * Count pending users
   * @return null|string
  */
  public function count_pending_user( $is_pending = true ) {
    $sql = "SELECT COUNT(*) FROM {$this->table_name} WHERE is_pending='{$is_pending}'";
    return $this->db->get_var( $sql );
  }

  /**
   * Get Referer user
   * @param int $id
   * @return array
   */
  public function get_ref_user($id) {
    $user_data = get_userdata($id);
    return array(
      'name' => $user_data->display_name,
      'username' => $user_data->user_nicename,
      'email' => $user_data->user_email,
      'url' => get_edit_user_link($id)
    );
  }

  public function has_username_in_pending_list($username) {
    $sql = "SELECT COUNT(*) FROM {$this->table_name} WHERE username='{$username}'";
    return (int) $this->db->get_var( $sql );
  }

  public function has_email_in_pending_list($email) {
    $sql = "SELECT COUNT(*) FROM {$this->table_name} WHERE email='{$email}'";
    return (int) $this->db->get_var( $sql );
  }

  public function update_pending_user_status($id) {

    $update = $this->db->update( $this->table_name, array(
        "is_pending" => false,
      ), array(
        "id" => $id
      ) );


  }

  public function get_pending_user_by_id($id, $fields = '' ) {

    $sql = "SELECT * FROM {$this->table_name} WHERE id={$id}";

    if(!empty($fields)) {
      $sql = "SELECT {$fields} FROM {$this->table_name} WHERE id={$id}";
    }

    return $this->db->get_row( $sql );

  }

  public function get_entry($pending_user_id = null, $ref_user_id = null) {
    $sql = "SELECT * FROM {$this->table_name} WHERE id={$pending_user_id} AND ref_user_id=$ref_user_id";

    return $this->db->get_row( $sql );

  }

  public function create_user($user_data) {

    if( username_exists( $user_data->username ) ) return;

    $insert_fields = array(
      'user_pass'       => $user_data->password,
      'user_login'      => $user_data->username,
      'user_email'      => $user_data->email,
      'user_nicename'   => $user_data->username,
      'first_name'      => $user_data->first_name,
      'last_name'        => $user_data->surname,
      'user_registered' => date("Y-m-d H:i:s"),
      'role'            => $user_data->role
    );

    $user_id = wp_insert_user( $insert_fields );


    if(!$user_id) return;

    add_user_meta( $user_id, 'salutation', $user_data->salutation );
    add_user_meta( $user_id, 'chamber', $user_data->guild );
    add_user_meta( $user_id, 'street', $user_data->street );
    add_user_meta( $user_id, 'street_num', $user_data->house_no );
    add_user_meta( $user_id, 'zip_code', $user_data->postcode );
    add_user_meta( $user_id, 'place', $user_data->city );
    add_user_meta( $user_id, 'phone', $user_data->phone );
    add_user_meta( $user_id, 'role', $user_data->role );

    $this->delete_pending_user($user_data->id);

    return $user_id;

  }

}
