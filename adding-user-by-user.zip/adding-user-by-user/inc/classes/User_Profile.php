<?php
namespace AUBU;
defined('ABSPATH') or die('Prevent direct access!');

class User_Profile {

  /**
  * Constructor
  * @version 1.1.1
  */

  public function __construct() {

    add_action( 'show_user_profile', array( $this, 'aubu_profile_fields' ) );
    add_action( 'edit_user_profile', array( $this, 'aubu_profile_fields' ) );

  }

  public function aubu_profile_fields( $user ) {
      $created_users_info = get_user_meta( $user->ID, AUBU_KEY_CREATED_USERS_INFO );
      if($created_users_info) :
    ?>
      <h3><?php _e( 'This user has created the following users', 'adding-user-by-user' ); ?></h3>
      <ol>
      <?php

          foreach( $created_users_info as $info ) :

      ?>
          <li><strong><?php echo $info['user_name']; ?> : <?php echo $info['creation_date']; ?></strong></li>
      <?php
          endforeach;
      ?>


      </ol>

      <?php endif; ?>

      <?php
        $requested_by_user_info = get_user_meta( $user->ID, AUBU_KEY_REQUESTED_BY_USER_INFO, true );

        if( $requested_by_user_info ):
      ?>
      <h2><?php echo sprintf('%s <strong>%s : %s</strong>', __( 'This user was requested by', 'adding-user-by-user' ), $requested_by_user_info[ 'user_name' ], $requested_by_user_info[ 'creation_date' ] ); ?> </h2>

      <?php endif; ?>

    <?php

  }


}
