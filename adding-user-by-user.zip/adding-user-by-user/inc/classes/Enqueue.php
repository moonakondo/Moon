<?php
namespace AUBU;

/**
  * To enqueue scripts and styles
*/
class Enqueue {

  static function enqueue_backend_js() {
    wp_enqueue_script( 'aubu-backend-js' );
  }

  static function enqueue_frontend_add_user_js() {
    wp_enqueue_script( 'aubu-frontend-add-user-js' );
  }

  static function enqueue_validate_js() {
    wp_enqueue_script( 'aubu-jquery-validate-js' );
  }

  static function enqueue_frontend_set_password_js() {
    wp_enqueue_script( 'aubu-frontend-set-password-js' );
  }

}
