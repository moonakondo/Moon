<?php
namespace AUBU;

defined('ABSPATH') or die ('Prevent direct access');

class Prepare_Data {

  /**
   * Get formated name
   * @param string $salutation Salutation
   * @param string $first_name First Name
   * @param string $surname Surname
   * @return string Mr. John (Doe) or '—'
   */

  public function get_name($salutation, $first_name, $surname) {
    $salutation = $salutation ? ucfirst($salutation) . ' ' : '';
    $first_name = $first_name ? ucfirst($first_name) . ' ' : '';
    $surname = $surname ? "(" . ucfirst($surname) . ")" : '';

    $name = $salutation . $first_name . $surname;

    if(!empty($name)) return esc_html($name);

    return '—';

  }

  /**
   * Get formatted address
   * @param array $address_fields with adsress fields
   * @return string
   */

  public function get_address($address_fields) {

    // Street
    $street = $address_fields['street'] ?
      sprintf( '<strong>%s: </strong>', __('Road:', 'adding-user-by-user') ) .
      esc_html( $address_fields['street'] ) .
      '<br/>' :
      '';

    // House No.
    $house_no = $address_fields['house_no'] ?
      sprintf( '<strong>%s: </strong>', __('House Number:', 'adding-user-by-user') ) .
      esc_html( $address_fields['house_no'] ) .
      '<br/>' :
      '';

    // Post code
    $postcode = $address_fields['postcode'] ?
      sprintf( '<strong>%s: </strong>', __('Post Code:', 'adding-user-by-user') ) .
      esc_html( $address_fields['postcode'] ) .
      '<br/>' :
      '';

    // City
    $city = $address_fields['city'] ?
      sprintf( '<strong>%s: </strong>', __('City:', 'adding-user-by-user') ) .
      esc_html( $address_fields['city'] ) .
      '<br/>' :
      '';

    // City
    $phone = $address_fields['phone'] ?
      sprintf( '<strong>%s: </strong>', __('Phone Number:', 'adding-user-by-user') ) .
      esc_html( $address_fields['phone'] ) .
      '<br/>' :
      '';

    $address = $street . $house_no . $postcode . $city . $phone;

    if(!empty($address)) return $address;

    return '—';

  }

  /**
   * Get added by user info
   * @param DB_Table object
   * @param int $id - ID of that user
   * @return string
   */
  public function get_added_by(DB_Table $db_table, $id) {

    $ref_user_info = $db_table->get_ref_user($id);

    $added_by = $ref_user_info['username'] ?
      '<a target="blank" href="' .
       esc_url($ref_user_info['url']) . '">' .
       esc_html($ref_user_info['username']) .
      '</a>'
      : '';

      if(!empty($added_by)) return $added_by;

      return '—';

  }

}
