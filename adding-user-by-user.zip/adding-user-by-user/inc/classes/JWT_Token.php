<?php
namespace AUBU;

use Firebase\JWT\JWT;

defined('ABSPATH') or die('Prevent direct access!');

class JWT_Token {

  private static $algorithm = 'HS256';
  private static $key = "A-tKb[@;t<_G]mN.-EK3?,G#mv`RJWy(M@[.(g+nDJ{HAB>*e;VDA?-(5^Khe+Gh(q[]\,6dt+4MF`v.R~C%$:u`/r_w>bj6n@{zx`!T>g'2N^/`>T^%>JzD@ZXy-r>\VaYhJj-Wwa>:SDu~4ttj{-(qMS'ba*Y}4,}eQx`mTkP<@Xwv_^][jyyr]V74,ZbPQY{xQB'h_f8d_6V&mL@3PQtv2B'F<n+`w*M?x`LS!aWj2D4_vtL:6LU5!@/'!2wh";

  public static function get_jwt($pending_user_id, $ref_user_id) {

    $payload = array(
      'pending_user_id' => $pending_user_id,
      'ref_user_id' => $ref_user_id
    );

    $jwt = JWT::encode($payload, self::$key, self::$algorithm );

    return $jwt;

  }

  public static function decode_jwt($token) {
    try {
      $decoded = JWT::decode($token, self::$key, array( self::$algorithm ));
      return $decoded;
    } catch( \Exception $e ) {
      echo $e->getMessage();
      return false;
    }
  }

}
