<?php
namespace AUBU;

defined('ABSPATH') or die('Prevent direct access');

use AUBU\DB_Table;
use WP_REST_Controller;
use WP_REST_Server;
use WP_REST_Response;
use WP_Error;


// TODO: validation and sanitize data

class REST_Controller extends WP_REST_Controller {

  private $db_table;

  public function __construct() {
    $this->db_table = new DB_Table();
  }

  /**
   * Register Routes
  */

  public function register_routes() {

    // Route to save user data
    register_rest_route( AUBU_REST_API_NAMASPACE, AUBU_ENDPOINT_SAVE_USER_DATA, array(
      array(
        'methods'             => WP_REST_Server::CREATABLE,
        'callback'            => array( $this, 'save_user_data' ),
        'permission_callback' => array($this, 'user_permission_check'),
        'args'                => $this->get_endpoint_args_for_item_schema( true )
      ),
    ) );

    // Route to check if username exists
    register_rest_route(AUBU_REST_API_NAMASPACE, AUBU_ENDPOINT_HAS_NO_USERNAME, array(
      array(
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => array( $this, 'has_no_username' ),
        'permission_callback' => array($this, 'user_permission_check'),
        'args'                => $this->get_endpoint_args_for_item_schema( true )
      )
    ));


    // Route to check if email address exists
    register_rest_route(AUBU_REST_API_NAMASPACE, AUBU_ENDPOINT_HAS_NO_EMAIL, array(
      array(
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => array( $this, 'has_no_email' ),
        'permission_callback' => array($this, 'user_permission_check'),
        'args'                => $this->get_endpoint_args_for_item_schema( true )
      )
    ));

    // Route to get pending users info
    register_rest_route(AUBU_REST_API_NAMASPACE, AUBU_ENDPOINT_GET_PENDING_USER, array(
      array(
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => array( $this, 'get_pending_user_by_id' ),
        'permission_callback' => array($this, 'user_permission_check'),
        'args'                => $this->get_endpoint_args_for_item_schema( true )
      )
    ));

    // Route to create user
    /*
    register_rest_route(AUBU_REST_API_NAMASPACE, AUBU_ENDPOINT_CREATE_USER, array(
      array(
        'methods'             => WP_REST_Server::CREATABLE,
        'callback'            => array( $this, 'create_user' ),
        'permission_callback' => '__return_true',
        'args'                => $this->get_endpoint_args_for_item_schema( true )
      )
    ));
    */

  }

  public function save_user_data($request) {
    if( !empty($request) ) {

      $insert = '';

      if($this->has_username_or_email($request)) {
        return new WP_Error( 'cant-create', __('Can not save user data due to duplication.', 'adding-user-by-user'), array( 'status' => 500 ) );
      }

      if(!$this->pass_required_fields($request)) {
        return new WP_Error( 'cant-create', __('Can not save user data due to required field(s).', 'adding-user-by-user'), array( 'status' => 500 ) );
      }

      $insert = $this->db_table->insert_pending_user_data($request);

      if(!empty($insert)) {
        $response = array(
          "message" => "user data saved successfully!",
          "payload" => array(
            "id" => $insert[0]->id,
            "username" => $insert[0]->username,
            "email" => $insert[0]->email
          )
        );

        // send mail to admin
        \AUBU\Mail::to_admin( absint( $insert[0]->id ), $this->db_table);

        return new WP_REST_Response( $response, 200 );
      }

    }

    return new WP_Error( 'cant-create', __('Can not save user data.', 'adding-user-by-user'), array( 'status' => 500 ) );
  }

  public function user_permission_check($request) {

    $user = wp_get_current_user();
    $is_allowed = array_intersect( AUBU_ALLOWED_USER_ROLES, $user->roles );
    $is_allowed = (bool) $is_allowed;


    if( $is_allowed ) {
      return true;
    }

    return false;

  }

  public function has_no_username($request) {
    try {
      $has_user_in_user_list = username_exists($request['username']);
      $has_user_in_pending_user_list = $this->db_table->has_username_in_pending_list( $request['username'] );
      $response = !($has_user_in_user_list || $has_user_in_pending_user_list);
      return new WP_REST_Response( $response, 200 );
    }
    catch( \Exception $e ) {
      echo $e->getMessage();
    }
  }

  public function has_no_email($request) {
    try {
      $has_email_in_user_list = email_exists($request['email']);
      $has_email_in_pending_user_list = $this->db_table->has_email_in_pending_list( $request['email'] );
      $response = !($has_email_in_user_list || $has_email_in_pending_user_list);
      return new WP_REST_Response( $response, 200 );
    }
    catch( \Exception $e ) {
      echo $e->getMessage();
    }
  }

  public function has_username_or_email($request) {
    $has_user_in_user_list = username_exists($request['username']);
    $has_user_in_pending_user_list = $this->db_table->has_username_in_pending_list( $request['username'] );
    $has_email_in_user_list = email_exists($request['email']);
    $has_email_in_pending_user_list = $this->db_table->has_email_in_pending_list( $request['email'] );

    return $has_user_in_user_list || $has_user_in_pending_user_list || $has_email_in_user_list || $has_email_in_pending_user_list;
  }
  // TODO: validate username, email, and password
  public function pass_required_fields($request) {
    return !empty(trim($request[ 'ref_user_id' ])) &&
    !empty(trim($request[ 'username' ])) &&
    !empty(trim($request[ 'salutation' ])) &&
    !empty(trim($request[ 'first_name' ])) &&
    !empty(trim($request[ 'surname' ])) &&
    !empty(trim($request[ 'email' ])) &&
    !empty(trim($request[ 'guild' ])) &&
    !empty(trim($request[ 'street' ])) &&
    !empty(trim($request[ 'house_no' ])) &&
    !empty(trim($request[ 'postcode' ])) &&
    !empty(trim($request[ 'city' ])) &&
    !empty(trim($request[ 'phone' ]));
  }

  public function get_pending_user_by_id($request) {

    try {
      $pending_user = $this->db_table->get_pending_user_by_id($request['id'], $request['fields']);

      return new WP_REST_Response( $pending_user, 200 );
    } catch( \Exception $e ) {
      return new WP_Error( 'cant-get-pending-user', $e->getMessage(), array( 'status' => 500 ) );
    }

  }

  public function create_user($request) {

    $decoded = \AUBU\JWT_Token::decode_jwt($request['token']);

    if(!$decoded) return;

    $password = esc_sql( $request['password'] );
    $confirm_password = esc_sql( $request['confirm_password'] );

    $is_valid_password = \AUBU\Verify_Input::is_valid_password( $password, $confirm_password );

    if(!$is_valid_password) return;

    $data = $this->db_table->get_entry( $decoded->pending_user_id, $decoded->ref_user_id );

    $data->password = $password;

    try {
      $create_user = $this->db_table->create_user( $data );

      return new WP_REST_Response( $create_user, 200 );
    } catch( \Exception $e ) {
      return new WP_Error( 'cant-get-pending-user', $e->getMessage(), array( 'status' => 500 ) );
    }

  }

}
