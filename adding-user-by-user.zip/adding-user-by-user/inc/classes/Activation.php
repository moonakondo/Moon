<?php
namespace AUBU;

class Activation {

  private $db;
  private $db_table;
  private $current_user;

  function __construct() {

    if(!current_user_can('activate_plugin')) return;
    global $wpdb;

    $this->db = $wpdb;
    $this->current_user = wp_get_current_user();
    $this->db_table = new \AUBU\DB_Table();


  }

  // Create a table to store all data
  function create_table() {
    $this->db_table->create_pending_user_table();
  }

  // create the add new user page
  public function create_add_user_page() {
    // check if the page exists
    $sql = sprintf("SELECT post_name FROM {$this->db->prefix}posts WHERE post_name='%s'", AUBU_ADD_NEW_USER_PAGE_SLUG);

    if( null === $this->db->get_row( $sql, "ARRAY_A" ) ) {

      $page_option = array(
        'post_title' => __('Add new user', 'adding-user-by-user'),
        'post_name' => AUBU_ADD_NEW_USER_PAGE_SLUG,
        'post_status' => 'publish',
        'post_author' => $this->current_user->ID,
        'post_type' => 'page',
        'post_content' => sprintf('[%s]', AUBU_SHORTCODE_ADD_USER_FORM)
      );

      wp_insert_post($page_option);
    }
  }

  // create the set password page
  public function create_set_password_page() {
    // check if the page exists
    $sql = sprintf("SELECT post_name FROM {$this->db->prefix}posts WHERE post_name='%s'", AUBU_SET_PASSWORD_PAGE_SLUG);

    if( null === $this->db->get_row( $sql, "ARRAY_A" ) ) {

      $page_option = array(
        'post_title' => __('Set a password', 'adding-user-by-user'),
        'post_name' => AUBU_SET_PASSWORD_PAGE_SLUG,
        'post_status' => 'publish',
        'post_author' => $this->current_user->ID,
        'post_type' => 'page',
        'post_content' => sprintf('[%s]', AUBU_SHORTCODE_SET_PASSWORD_FORM)
      );

      wp_insert_post($page_option);
    }
  }

}
