<?php
namespace AUBU;

defined('ABSPATH') or die('Prevent direct access!');

use AUBU\Pending_User_List_Table;
use AUBU\Prepare_Data;


class Admin_Option{

  private $list_table;
  private $db_table;
  private $total_pending_user_approval;
  private $total_pending_user_password_confirmation;
  private $page_approval;
  private $page_password_confirmation;

  public function __construct(DB_Table $db_table) {

      $current_page = isset($_GET) && isset($_GET['page']) ? $_GET['page'] : '';
      $this->page_approval = $current_page === AUBU_PAGE_APPROVAL_LIST;
      $this->page_password_confirmation = $current_page === AUBU_PAGE_PASSWORD_CONFIRMATION_LIST;

      $this->db_table = $db_table;
      $this->total_pending_user_approval = $db_table->count_pending_user( true );
      $this->total_pending_user_password_confirmation = $db_table->count_pending_user( false );


      // add subsubsub quick links in user - pending for approval
      add_filter('views_users', array($this, 'create_subsubsub_menu'));

      // add screen option
      add_filter('set-screen-option', array(__CLASS__, 'set_screen'), 10, 3);

      // custom page to view and approve user
      add_action('admin_menu', array($this, 'create_submenu_page'));


  }
  // create subsubsub menu under user
  public function create_subsubsub_menu($views) {

    // Pending users for approval
    $views[AUBU_PAGE_APPROVAL_LIST] = sprintf('<a href="users.php?page=%s">%s <span class="count">(%u)</span></a>', AUBU_PAGE_APPROVAL_LIST, __('Created by user', 'adding-user-by-user'), $this->total_pending_user_approval);

     // Pending users for password confirmation
     $views[AUBU_PAGE_PASSWORD_CONFIRMATION_LIST] = sprintf('<a href="users.php?page=%s">%s <span class="count">(%u)</span></a>', AUBU_PAGE_PASSWORD_CONFIRMATION_LIST, __('Waiting for password confirmation', 'adding-user-by-user'), $this->total_pending_user_password_confirmation);

    return $views;
  }

  public function create_submenu_page() {

    // submenu - pening for approval
    $hook_approval = add_submenu_page(
      'users.php',
      'User by User Approval',
      'Pending Users for approval',
      'edit_pages',
      AUBU_PAGE_APPROVAL_LIST,
      array($this, 'pending_user_list_page')
    );

    add_action("load-$hook_approval", array( $this, 'screen_option' ));

    // submenu - pening for password confirmation
    $hook_password_confirmation = add_submenu_page(
      'users.php',
      'User by User Set Password',
      'Pending Users for password confirmation',
      'edit_pages',
      AUBU_PAGE_PASSWORD_CONFIRMATION_LIST,
      array($this, 'password_confirmation_user_list_page')
    );

    add_action("load-$hook_password_confirmation", array( $this, 'screen_option' ));

    // remove menu item
    remove_submenu_page('users.php', AUBU_PAGE_APPROVAL_LIST);
    remove_submenu_page('users.php', AUBU_PAGE_PASSWORD_CONFIRMATION_LIST);

  }

  public function pending_user_list_page() {
    \AUBU\Enqueue::enqueue_backend_js();
  ?>
		<div class="wrap">
			<h1><?php _e( 'Created by user. Approval is still pending. (added by existing user)', 'adding-user-by-user' ); ?></h1>

      <ul class="subsubsub">
      	<li class="all">
          <a href="users.php" aria-current="page">Alle Benutzer</a> |
        </li>
      	<li class="<?php echo AUBU_PAGE_APPROVAL_LIST; ?>">
          <a href="users.php?page=<?php echo AUBU_PAGE_APPROVAL_LIST; ?>" class="<?php echo $this->page_approval ? 'current' : ''; ?>">
            <?php _e( 'Created by user', 'adding-user-by-user' ); ?>
            <span class="count">(<?php echo $this->total_pending_user_approval;?>)</span>
          </a>
        </li>
      	<li class="<?php echo AUBU_PAGE_PASSWORD_CONFIRMATION_LIST; ?>">
          <a href="users.php?page=<?php echo AUBU_PAGE_PASSWORD_CONFIRMATION_LIST; ?>" class="<?php echo $this->page_password_confirmation ? 'current' : ''; ?>">
            <?php echo __('Waiting for password confirmation', 'adding-user-by-user'); ?>
            <span class="count">(<?php echo $this->total_pending_user_password_confirmation;?>)</span>
          </a>
        </li>
      </ul>

      <form method="post" id="aubu-pending-user-list-form">
        <?php
        $this->list_table->prepare_items();
        $this->list_table->display(); ?>
      </form>

      <style>
        .row-actions .decline a {
          color: #a00;
        }
        .row-actions .decline a:hover {
          color: #dc3232;
        }
        .row-actions .approve {
          display: inline;
        }
      </style>
		</div>
	<?php
  }


  public function password_confirmation_user_list_page() {
    \AUBU\Enqueue::enqueue_backend_js();

  ?>
		<div class="wrap">
			<h1><?php _e( 'Created by user. Approval is still pending. (added by existing user)', 'adding-user-by-user'); ?></h1>

      <ul class="subsubsub">
      	<li class="all">
          <a href="users.php" aria-current="page">Alle Benutzer</a> |
        </li>
      	<li class="<?php echo AUBU_PAGE_APPROVAL_LIST; ?>">
          <a href="users.php?page=<?php echo AUBU_PAGE_APPROVAL_LIST; ?>" class="<?php echo $this->page_approval ? 'current' : ''; ?>">
            <?php _e( 'Created by user', 'adding-user-by-user' ); ?>
            <span class="count">(<?php echo $this->total_pending_user_approval;?>)</span>
          </a>
        </li>
      	<li class="<?php echo AUBU_PAGE_PASSWORD_CONFIRMATION_LIST; ?>">
          <a href="users.php?page=<?php echo AUBU_PAGE_PASSWORD_CONFIRMATION_LIST; ?>" class="<?php echo $this->page_password_confirmation ? 'current' : ''; ?>">
            <?php echo __('Waiting for password confirmation', 'adding-user-by-user'); ?>
            <span class="count">(<?php echo $this->total_pending_user_password_confirmation;?>)</span>
          </a>
        </li>
      </ul>

      <form method="post" id="aubu-pending-user-list-form">
        <?php
        $this->list_table->prepare_items( false );
        $this->list_table->display(); ?>
      </form>

      <style>
        .row-actions .decline a {
          color: #a00;
        }
        .row-actions .decline a:hover {
          color: #dc3232;
        }
        .row-actions .approve {
          display: inline;
        }
      </style>
		</div>
	<?php
  }

  public function set_screen($status, $option, $value) {
    return $value;
  }

  public function screen_option() {
    $option = 'per_page';
    $args = array(
      'label' => 'Users',
      'default' => 5,
      'option' => 'users_per_page'
    );

    add_screen_option( $option, $args );

    $formatted_data = new Prepare_Data();

    $this->list_table = new Pending_User_List_Table($this->db_table, $formatted_data);

  }

}
