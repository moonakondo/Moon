<?php
namespace AUBU;
use AUBU\Enqueue;
use AUBU\JWT_Token;
use Firebase\JWT\JWT;


class Shortcode {

  private $db_table;

  function __construct( DB_Table $db_table ) {

    $this->db_table = $db_table;

    add_shortcode( AUBU_SHORTCODE_ADD_USER_FORM, array( $this, 'add_new_user_form' ) );
    add_shortcode( AUBU_SHORTCODE_SET_PASSWORD_FORM, array( $this, 'set_password_form' ) );
  }

  function add_new_user_form() {

    // enqueue frontend script when this shortcode load
    Enqueue::enqueue_validate_js();
    Enqueue::enqueue_frontend_add_user_js();

    $user = wp_get_current_user();
    $is_allowed = array_intersect( AUBU_ALLOWED_USER_ROLES, $user->roles );
    $is_allowed = (bool) $is_allowed;


    if( !$is_allowed ) {
      return $this->get_not_found_template();
    }

    ob_start();
    include_once AUBU_BASE_PATH . "template/add-user-form.php";
    $content = ob_get_clean();
    return $content;
  }

  function set_password_form() {
    Enqueue::enqueue_validate_js();
    Enqueue::enqueue_frontend_set_password_js();

    // show not found page if no token provided
    if(empty( $_GET['token'] ) || !isset( $_GET['token'] ) || !$_GET['token']) {
      return $this->get_not_found_template();
    }
    $payload = JWT_Token::decode_jwt($_GET['token']);

    if(!$payload) {
      return $this->get_not_found_template();
    }

    $get_entry = $this->db_table->get_entry( $payload->pending_user_id, $payload->ref_user_id );

    if(!$get_entry) {
      return $this->get_not_found_template();
    }

    ob_start();
    include_once AUBU_BASE_PATH . "template/set-password-form.php";
    $content = ob_get_clean();
    return $content;
  }

  public function get_not_found_template() {
    ob_start();
    include_once AUBU_BASE_PATH . "template/not-found.php";
    $content = ob_get_clean();
    return $content;
  }

}
