<?php
namespace AUBU;

use AUBU\Mail;

defined('ABSPATH') or die('Prevent direct access!');

if( !class_exists( 'WP_List_Table' ) ) {
  require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Pending_User_List_Table extends \WP_List_Table {

  private $db_table;
  private $formatted_data;

	/** Class constructor */
	public function __construct(DB_Table $db_table, Prepare_Data $formatted_data) {

    $this->db_table = $db_table;
    $this->formatted_data = $formatted_data;

		parent::__construct( array(
			'singular' => __( 'Pending User', 'adding-user-by-user' ),
			'plural'   => __( 'Pending  Users', 'adding-user-by-user' ),
			'ajax'     => false
		) );

	}

	/**
   * Text displayed when no pending user data is available
   */
	public function no_items() {
		_e( 'There are no pending users.', 'adding-user-by-user' );
	}


	/**
	 * Render a column when no column specific method exist.
	 *
	 * @param array $item
	 * @param string $column_name
	 *
	 * @return mixed
	 */
	public function column_default( $item, $column_name ) {

    $hfn = function($fn) {
      return $fn;
    };

    $address_fields = array(
      'street' => $item[ 'street' ],
      'house_no' => $item[ 'house_no' ],
      'postcode' => $item[ 'postcode' ],
      'city' => $item[ 'city' ],
      'phone' => $item[ 'phone' ],
    );


		switch ( $column_name ) {
      case 'name':
        return $this->formatted_data->get_name($item[ 'salutation' ], $item[ 'first_name' ], $item[ 'surname' ]);
			case 'email':
				return $item[ $column_name ] ? esc_html( $item[ $column_name ] ) : '—';
      case 'guild':
        return $item[ $column_name ] ? esc_html( $item[ $column_name ] ) : '—';
      case 'role':
        return $item[ $column_name ] ? esc_html( $item[ $column_name ] ) : '—';
			case 'address':
				return $this->formatted_data->get_address($address_fields);
      case 'added_by':
        return $this->formatted_data->get_added_by($this->db_table, $item[ 'ref_user_id' ]);
			default:
				return print_r( $item, true ); //Show the whole array for troubleshooting purposes
		}

	}

	/**
	 * Render the bulk edit checkbox
	 *
	 * @param array $item
	 *
	 * @return string
	 */
	function column_cb( $item ) {
    $input_fields = sprintf('<input type="checkbox" name="pending_users[]" value="%s" class="%s" />', $item['id'], "aubu-bulk-checkbox");
    $input_fields .= sprintf('<input type="hidden" name="ref_users[]" value="%s" />', $item['ref_user_id']);
		return $input_fields;
	}


	/**
	 * Method for username column
	 *
	 * @param array $item an array of DB data
	 *
	 * @return string
	 */
	function column_username( $item ) {

		$delete_nonce = wp_create_nonce( 'aubu_delete_user' );
    $approve_nonce = wp_create_nonce( 'aubu_approve_user' );

		$title = $item[ 'username' ] ? '<strong>' . $item[ 'username' ] . '</strong>' : '—';

    if ( isset($_REQUEST) && $_REQUEST['page'] == AUBU_PAGE_APPROVAL_LIST ) {
      $remove_text = __('Decline', 'adding-user-by-user');
    }elseif( isset($_REQUEST) && $_REQUEST['page'] == AUBU_PAGE_PASSWORD_CONFIRMATION_LIST ) {
      $remove_text = __('Remove', 'adding-user-by-user');
    }

    $actions['decline'] = sprintf( '<a href="?page=%s&action=%s&pending_user_id=%d&_wpnonce=%s" class="%s" >%s</a>',
                            esc_attr( $_REQUEST['page'] ),
                            'decline',
                            absint( $item['id'] ),
                            $delete_nonce,
                            'aubu_decline_btn',
                            $remove_text );


    if ( isset($_REQUEST) && $_REQUEST['page'] == AUBU_PAGE_APPROVAL_LIST ) {

      $actions['approve'] = sprintf(
          '<a href="?page=%s&action=%s&pending_user_id=%s&ref_user_id=%s&_wpnonce=%s" class="%s" >%s</a>',
          esc_attr( $_REQUEST['page'] ),
          'approve',
          absint( $item['id'] ),
          absint( $item['ref_user_id'] ) ,
          $approve_nonce,
          'aubu_approve_btn',
          __('Approve', 'adding-user-by-user') );

    }


		return $title . $this->row_actions( $actions );
	}

	/**
	 *  Associative array of columns
	 *
	 * @return array
	 */
	function get_columns() {

		$columns = [
			'cb'            => '<input type="checkbox" />',
      'username'      => __( 'Username', 'adding-user-by-user' ),
      'name'          => __( 'Name', 'adding-user-by-user' ),
			'email'         => __( 'Email', 'adding-user-by-user' ),
      'guild'         => __( 'Guild', 'adding-user-by-user' ),
      'role'          => __( 'Role', 'adding-user-by-user' ),
      'address'       => __( 'Address', 'adding-user-by-user' ),
      'added_by'      => __( 'Added By', 'adding-user-by-user' ),
		];

		return $columns;

	}


	/**
	 * Columns to make sortable.
	 *
	 * @return array
	 */
	public function get_sortable_columns() {
		$sortable_columns = array(
      'username'   => array( 'username', true ),
			'email'      => array( 'email', true ),
			'guild'      => array( 'guild', true ),
      'role' => array( 'role', true ),
			'added_by'   => array( 'ref_user_id', true )
		);

		return $sortable_columns;
	}

	/**
	 * Returns an associative array containing the bulk action
	 *
	 * @return array
	 */
	public function get_bulk_actions() {


    if ( isset($_REQUEST) && $_REQUEST['page'] == AUBU_PAGE_APPROVAL_LIST ) {
      /**
      * TODO: Mario
      * Translate bulk-action name - https://i.imgur.com/mHvEEo2.png
      * 'Decline'
      * 'Approve'
      */
      $actions = [
        'bulk-decline' => __('Decline', 'adding-user-by-user'),
        'bulk-approve' => __('Approve', 'adding-user-by-user')
      ];
    }elseif( isset($_REQUEST) && $_REQUEST['page'] == AUBU_PAGE_PASSWORD_CONFIRMATION_LIST ) {
      $actions = [
        'bulk-decline' => __('Remove', 'adding-user-by-user'),
      ];
    }


		return $actions;
	}

	/**
	 * Handles data query and filter, sorting, and pagination.
	 */
	public function prepare_items( $is_pending = true ) {
		/** Process action */
		$this->_column_headers = $this->get_column_info();

    $this->process_action();
    $this->process_bulk_action();

		$per_page     = $this->get_items_per_page( 'users_per_page', 10 );
		$current_page = $this->get_pagenum();
		$total_items  = $this->db_table->count_pending_user( $is_pending );

		$this->set_pagination_args( [
			'total_items' => $total_items, //WE have to calculate the total number of items
			'per_page'    => $per_page //WE have to determine how many items to show on a page
		] );

		$this->items = $this->db_table->get_all_pending_users( $per_page, $current_page, $is_pending );

	}

  public function process_action() {
    if ( 'decline' === $this->current_action() ) {

      // In our file that handles the request, verify the nonce.
      $nonce = esc_attr( $_REQUEST['_wpnonce'] );

      if ( ! wp_verify_nonce( $nonce, 'aubu_delete_user' ) ) {
        die( 'Go get a life, script kiddies!' );
      } else {
        $this->db_table->delete_pending_user( absint( $_GET['pending_user_id'] ) );
        $this->redirect_to_main( $_REQUEST['page'] );
      }

    } elseif ('approve' === $this->current_action() ) {

      $nonce = esc_attr( $_REQUEST['_wpnonce'] );

      if( ! wp_verify_nonce( $nonce, 'aubu_approve_user' )) {
        die( 'Go get a life, script kiddies!' );
      } else {
        Mail::to_pending_user( absint( $_GET['pending_user_id'] ), $this->db_table );
        Mail::to_ref_user( absint( $_GET['ref_user_id'] ), $this->db_table );
        $this->db_table->update_pending_user_status( absint( $_GET['pending_user_id'] )  );
        $this->redirect_to_main( $_REQUEST['page'] );
      }
    }
  }


	public function process_bulk_action() {
		// If the decline bulk action is triggered
		if ( 'bulk-decline' === $this->current_action() && !empty($_POST['pending_users']) ) {

			$delete_ids = esc_sql( $_POST['pending_users'] );

			// loop over the array of record IDs and decline them
			foreach ( $delete_ids as $id ) {
				$this->db_table->delete_pending_user( absint( $id ) );
			}

			$this->redirect_to_main( $_REQUEST['page'] );
		} elseif( 'bulk-approve' === $this->current_action() && !empty($_POST['pending_users']) && !empty($_POST['ref_users']) ) {
      $pending_user_ids = esc_sql( $_POST['pending_users'] );
      $ref_user_ids = esc_sql( $_POST['ref_users'] );

      foreach( array_combine( $pending_user_ids, $ref_user_ids ) as $pending_user_id => $ref_user_id ) {

        Mail::to_pending_user( absint( $pending_user_id ), $this->db_table );
        Mail::to_ref_user( absint( $ref_user_id ), $this->db_table );
        $this->db_table->update_pending_user_status( absint( $pending_user_id )  );
        $this->redirect_to_main( $_REQUEST['page'] );

      }
    }
	}

  public function redirect_to_main( $page_name ) {
    $url = esc_url_raw( add_query_arg( "page", $page_name, admin_url( 'users.php' ) ) );
    wp_redirect( $url );
    exit;
  }
}
