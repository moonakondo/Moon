<?php
namespace AUBU;
/**
  * register scripts and styles
*/

class Register {

  function __construct() {
    add_action('admin_enqueue_scripts', array($this, 'backend_scripts'));
    add_action('wp_enqueue_scripts', array($this, 'frontend_scripts'));
  }

  function backend_scripts() {
    wp_register_script( 'aubu-backend-js', AUBU_BASE_URL.'asset/js/backend.js', array('jquery'), AUBU_PLUGIN['version'], true);
  }

  function frontend_scripts() {

    // jQuery validate
    wp_register_script(
      'aubu-jquery-validate-js',
      AUBU_BASE_URL . 'asset/js/jquery.validate.min.js',
      array('jquery'),
      AUBU_PLUGIN['version'],
      true );

    // custom frontedn js
    wp_register_script( 'aubu-frontend-add-user-js',
      AUBU_BASE_URL.'asset/js/frontend-add-user.js',
      array('jquery', 'aubu-jquery-validate-js', 'wp-i18n'),
      AUBU_PLUGIN['version'],
      true );

    wp_register_script( 'aubu-frontend-set-password-js',
      AUBU_BASE_URL.'asset/js/frontend-set-password.js',
      array('jquery', 'aubu-jquery-validate-js'),
      AUBU_PLUGIN['version'],
      true );


    // Make available the API endpoint to JavaScript by localize
    wp_localize_script('aubu-frontend-add-user-js', 'route', array(
      'saveSubUserURL' => rest_url( AUBU_REST_API_NAMASPACE . AUBU_ENDPOINT_SAVE_USER_DATA ),
      'hasNoUsername'    => rest_url( AUBU_REST_API_NAMASPACE . AUBU_ENDPOINT_HAS_NO_USERNAME ),
      'hasNoEmail'    => rest_url( AUBU_REST_API_NAMASPACE . AUBU_ENDPOINT_HAS_NO_EMAIL ),
      'nonce' => wp_create_nonce( 'wp_rest' ),
    ));

    wp_localize_script('aubu-frontend-set-password-js', 'route', array(
      'createUserURL' => rest_url( AUBU_REST_API_NAMASPACE . AUBU_ENDPOINT_CREATE_USER ),
    ));

  }

}
