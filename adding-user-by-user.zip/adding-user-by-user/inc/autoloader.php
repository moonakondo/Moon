<?php
/*
 * autoloader for namespaces
*/

/* autoloader script */
spl_autoload_register('aubu_auto_loader');

function aubu_auto_loader($class_name) {

  // if the namespace comes from outside then duck out
  if(strpos( $class_name, 'AUBU' ) !== FALSE) {
    // includes all class files from this plugin
    $namespace_arr = explode("\\", $class_name);
    array_shift($namespace_arr);
    $file_path = implode(DIRECTORY_SEPARATOR, $namespace_arr);
    include_once AUBU_BASE_PATH . 'inc/classes/' . $file_path . '.php';
  } elseif(strpos( $class_name, 'Firebase\JWT' ) !== FALSE) {
    // includes all files from php-jwt library
    $namespace_arr = explode("\\", $class_name);
    array_shift($namespace_arr);
    array_shift($namespace_arr);
    $file_path = implode(DIRECTORY_SEPARATOR, $namespace_arr);
    include_once AUBU_BASE_PATH . 'lib/php-jwt/src/' . $file_path . '.php';
  } else {
    return;
  }
}
