<?php
// Silence is Golden
