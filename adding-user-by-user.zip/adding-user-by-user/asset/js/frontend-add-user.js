!(function($){

  const { __ } = wp.i18n;

  $(document).ready(function(){

    var salutation = '';
    var role = '';

    // Extend jquery validator
    $.validator.addMethod( "lettersWithUnderscoreAndNumber", function( value, element ) {
    	return this.optional( element ) || /^[a-z\_0-9]+$/i.test( value );
    }, __( 'Only letters, underscores and numbers are allowed', 'adding-user-by-user' ) );


    $('[name=salutation]').on('change', function(event) {
      salutation = $(this).val();
    })

    $('.aubu-error').hide();


    $('[name=username], [name=email]').on('input', function() {
      $(this).parent().find('.aubu-error').hide();
    });

    $("#aubu-add-new-user-form input").on('blur', function() {
      $(this).val($.trim($(this).val()));
    })

'adding-user-by-user'
    $('#aubu-add-new-user-form').validate({
      submitHandler: function(form) {

          $('#aubu-submit-btn').val( __( 'Submitting...', 'adding-user-by-user' ) );

          // Ajax request to specific API endpoint
          $.ajax({
            method: 'POST',
            dataType: 'json',
            url: route.saveSubUserURL,
            beforeSend: function( xhr ) {
              xhr.setRequestHeader( 'X-WP-Nonce', route.nonce );
            },
            data: {
              username: $('[name=username]').val(),
              salutation: salutation,
              first_name: $('[name=first_name]').val(),
              surname: $('[name=surname]').val(),
              email: $('[name=email]').val(),
              guild: $('[name=guild]').val(),
              street: $('[name=street]').val(),
              house_no: $('[name=house_no]').val(),
              postcode: $('[name=postcode]').val(),
              city: $('[name=city]').val(),
              phone: $('[name=phone]').val(),
              ref_user_id: $('[name=ref_user_id]').val(),
              role: $('[name=role]:checked').val(),
            }
          })
          .done(function(response) {
            if(response) {
              form.reset();
              $('#aubu-submit-btn').val(__('Submit', 'adding-user-by-user' ));
              $('.aubu_submit_success_message').show();
            }
          })
          .fail(function(){
            console.log( __('Something went wrong, user save failed.', 'adding-user-by-user' ) )
          })
          .always(function(response){
            // always reset requestrunning to keep sending new AJAX requests
            requestRunning = false;
          });

      },
      errorPlacement: function(error, element) {
        error.appendTo(element.parent())
      },
      rules: {
        username: {
          required: true,
          minlength: 3,
          maxlength: 100,
          lettersWithUnderscoreAndNumber: true,
          remote: {
            url: route.hasNoUsername,
            type: 'get',
            beforeSend: function( xhr ) {
              xhr.setRequestHeader( 'X-WP-Nonce', route.nonce );
            },
            data: {
               username: function() {
                 return $('[name=username]').val()
               }
            }
          }
        },
        salutation: {
          required: true,
        },
        first_name: {
          required: true,
          minlength: 3,
          maxlength: 50,
        },
        surname: {
          required: true,
          minlength: 3,
          maxlength: 50,
        },
        email: {
          required: true,
          minlength: 3,
          maxlength: 100,
          remote: {
            url: route.hasNoEmail,
            type: 'get',
            beforeSend: function( xhr ) {
              xhr.setRequestHeader( 'X-WP-Nonce', route.nonce );
            },
            data: {
               email: function() {
                 return $('[name=email]').val()
               }
            }
          }
        },
        guild: {
          required: true,
          maxlength: 50
        },
        street: {
          required: true,
          maxlength: 150
        },
        house_no: {
          required: true,
          maxlength: 150
        },
        postcode: {
          required: true,
          maxlength: 9
        },
        city: {
          required: true,
          maxlength: 50
        },
        phone: {
          required: true,
          maxlength: 20
        },
        role: {
          required: true,
          maxlength: 30
        },
      },
      messages: {
        username: {
          required: __( 'Username is required.', 'adding-user-by-user' ),
          remote: $.validator.format("'{0}' " + __( 'is already taken.', 'adding-user-by-user' ) )
        },
        salutation: {
          required: __( 'The salutation is required.', 'adding-user-by-user' )
        },
        first_name: {
          required: __( 'First name is required.', 'adding-user-by-user' )
        },
        surname: {
          required: __( 'Last name is required.', 'adding-user-by-user' )
        },
        email: {
          required: __( 'Email is required.', 'adding-user-by-user' ),
          remote: $.validator.format("'{0}' " + __( 'is already taken.', 'adding-user-by-user' ) )
        },
        guild: {
          required: __( 'Guild is required.', 'adding-user-by-user' )
        },
        street: {
          required: __( 'Street is required.', 'adding-user-by-user' )
        },
        house_no: {
          required: __( 'House number is required.', 'adding-user-by-user' )
        },
        postcode: {
          required: __( 'Post code is required.', 'adding-user-by-user' )
        },
        city: {
          required: __( 'City is required.', 'adding-user-by-user' )
        },
        phone: {
          required: __( 'Telephone number is required.', 'adding-user-by-user' )
        },
        role: {
          required: __( 'Role is required.', 'adding-user-by-user' )
        },
      }
    });

    // Hide/Show Ohter role text field
    /*
    var valueOher = 'other'

    $( '[name=role]' ).on( 'change', function() {

      if( $(this).val() === 'employee' || $(this).val() === 'trainee' ) {
        role = $(this).val();
        $( '.aubu_field_other_role input[type=text]' ).css( 'display', 'none' );
        $( '#role-' + $(this).val() ).prop( 'checked', true );
        $( '#role-other' ).val( valueOher );
        $( '.aubu_field_other_role input[type=text]' ).val( '' )
      }else {
        $( '.aubu_field_other_role input[type=text]' ).css( 'display', 'block' );
      }

    } )
    $( '.aubu_field_other_role input[type=text]' ).on( 'change', function() {
      if( $(this).val() != '' ) {
        role = $(this).val();
        $( '#role-other' ).val( $(this).val() );
      } else {
        role = valueOher;
        $( '#role-other' ).val( valueOher );
      }
    } )
    */

  });
})(jQuery);
