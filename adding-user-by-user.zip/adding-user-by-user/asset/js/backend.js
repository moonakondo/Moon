!(function($){
  $(document).ready(function(){

    $('.aubu_decline_btn, .aubu_approve_btn').on( 'click', function(e) {
       e.preventDefault();

       var confirmMsg =''

       if( $(this).attr('class') === 'aubu_decline_btn' ) {
         confirmMsg = 'Are you sure to decline the pending user.'
       }else if( $(this).attr('class') === 'aubu_approve_btn' ) {
         confirmMsg = 'Are you sure to approve the pending user.'
       }

       var isConfirm = confirm( confirmMsg );

       if(!isConfirm) return false;

       window.location.href = $(this).attr('href');

    })

    var actionForm = $("#aubu-pending-user-list-form");

    if(actionForm.length > 0) {
      actionForm.on('click', '#doaction, #doaction2', function(e) {
        e.preventDefault();

        var action = $(this).parent().find('#bulk-action-selector-top option:selected').val() ||
                  $(this).parent().find('#bulk-action-selector-bottom option:selected').val();

        if(action == -1) return false;
        if($('.aubu-bulk-checkbox:checked').length < 1) return false;


        if( action === 'bulk-decline' ) {
          confirmMsg = 'Are you sure to decline all selected pending users.';
        }else if( action === 'bulk-approve' ) {
          confirmMsg = 'Are you sure to approve all selected pending users.';
        }

        var isConfirm = confirm( confirmMsg );

        if( !isConfirm ) return false;

        $(this).closest('form').submit()


      })
    }

  });
})(jQuery);
