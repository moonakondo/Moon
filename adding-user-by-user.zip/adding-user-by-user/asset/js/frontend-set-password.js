!(function($){

  const { __ } = wp.i18n;

  $(document).ready(function(){

    $('#aubu-set-user-form').validate({
      submitHandler: function (form) {

        $('#aubu-submit-btn').val( __( 'Submitting...', 'adding-user-by-user' ) );

        form.submit();

        // Ajax request to specific API endpoint
        /*
        $.ajax({
          method: 'POST',
          dataType: 'json',
          url: route.createUserURL,
          data: {
            token: get_token(),
            password: $('[name=password]').val(),
            confirm_password: $('[name=confirm_password]').val()
          }
        })
        .done(function(response) {
          if(response) {
            form.reset();
            form.remove();
            $('.aubu_submit_success_message').show();
          }
        })
        .fail(function(){
          console.log("Etwas ist schief gelaufen, das Speichern des Benutzers ist fehlgeschlagen.")
        })
        .always(function(response){
          // always reset requestrunning to keep sending new AJAX requests
          requestRunning = false;
        });
		   */

      },
      rules: {
        password: {
          required: true,
          minlength: 8,
          maxlength: 256
        },
        confirm_password: {
          equalTo: "#password"
        }
      }
    })
    function get_token() {
      var urlParams = new URLSearchParams(window.location.search);
      return urlParams.get('token');
    }

  });
})(jQuery);
