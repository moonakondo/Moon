<?php
  $success = false;
  $error = false;

  if ( $_SERVER['REQUEST_METHOD'] == "POST" ) {

    $decoded = \AUBU\JWT_Token::decode_jwt($_GET['token']);

    if(!$decoded) return;

    $password = esc_sql( $_POST['password'] );
    $confirm_password = esc_sql( $_POST['confirm_password'] );

    $is_valid_password = \AUBU\Verify_Input::is_valid_password( $password, $confirm_password );

    if(!$is_valid_password) return;

    $data = $this->db_table->get_entry( $decoded->pending_user_id, $decoded->ref_user_id );

    $data->password = $password;

    try {
	    $create_user = $this->db_table->create_user( $data );

      if($create_user) {
        $success = true;

        $ref_user_info = $this->db_table->get_ref_user( $data->ref_user_id );

        add_user_meta( $create_user, AUBU_KEY_REQUESTED_BY_USER_INFO, array(
          'user_name' => $ref_user_info['username'],
          'creation_date'  => date('F d, Y')
        ) );

        // Redirect URL to the site URL
        /**
        * TODO: Mario
        * site_url() will print https://tehwr.newcloud.media as it is hosted here.
        * you can add redirect page slug afer '/' sign
        * for example '/test-page'
        * so redirect URL would be
        * $redirect_url = esc_url_raw( site_url() . '/test-page' );
        */
        $redirect_url = esc_url_raw( site_url() . '/' );
        wp_redirect( $redirect_url );
        die();
      }

    } catch( \Exception $e ) {
      $error = true;
      new WP_Error( 'cant-get-pending-user', $e->getMessage(), array( 'status' => 500 ) );
    }

  }

?>
<style>
  .aubu_submit_success_message,
  .aubu_submit_error_message {
    border: 2px solid #80ba73;
    padding: 10px;
    margin-top: 20px;
    border-radius: 5px;
    background: #fff;
  }
  .aubu_submit_error_message {
    border-color: #f00;
  }
  .aubu_submit_success_message p,
  .aubu_submit_error_message p {
    margin-bottom: 0;
  }
</style>
<div class="aubu_add_new_user_form_section">

  <?php if(!$success) : ?>
    <h2><?php _e( "Set a password", 'adding-user-by-user' ); ?></h2>
    <div class="aubu_add_new_user_form_wrapper">
      <form id="aubu-set-user-form" method="post" action="<?php echo htmlspecialchars( $_SERVER['REQUEST_URI'] ); ?>" style>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "Password", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="password" name="password" id="password" />
          </div>
        </div>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "Confirm the password", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="password" name="confirm_password" />
          </div>
        </div>

        <input type="submit" value="<?php _e( "Submit", 'adding-user-by-user' ); ?>" id="aubu-submit-btn" />

      </form>
    <?php endif; ?>

      <div class="aubu_submit_success_message" style="display: <?php echo $success ? 'block' : 'none'; ?>" >
        <p><?php _e( "Your registration is complete.", 'adding-user-by-user' ); ?></p>
      </div>
      <div class="aubu_submit_error_message" style="display: <?php echo $error ? 'block' : 'none'; ?>" >
        <p><?php _e( "Error! Something went wrong.", 'adding-user-by-user' ); ?></p>
      </div>
      <div class="aubu_submit_error_message" style="display: <?php echo $error ? 'block' : 'none'; ?>" >
        <p><?php _e( "Error! Something went wrong.", 'adding-user-by-user' ); ?></p>
      </div>
    </div>
</div>
