<?php
  global $current_user;
?>
<style>
  .aubu_submit_success_message {
    border: 2px solid #80ba73;
    padding: 10px;
    margin-top: 20px;
    border-radius: 5px;
    background: #fff;
  }
  .aubu_submit_success_message p {
    margin-bottom: 0;
  }
</style>
<div class="aubu_add_new_user_form_section">
    <h2><?php _e( "Add user", 'adding-user-by-user' ); ?></h2>
    <div class="aubu_add_new_user_form_wrapper">
      <form id="aubu-add-new-user-form" method="post">

        <input type="hidden" value="<?php echo $current_user->ID; ?>" name="ref_user_id" />

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "Username", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="text" name="username" />
            <span class="aubu_field_info"><?php _e( "Usernames cannot be changed.", 'adding-user-by-user' ); ?></span>
          </div>
        </div>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "Salutation", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="radio" name="salutation" value="Frau" /> <?php _e( "Mrs.", 'adding-user-by-user' ); ?>
            <input type="radio" name="salutation" value="Herr" /> <?php _e( "Mr.", 'adding-user-by-user' ); ?>
          </div>
        </div>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "First name", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="text" name="first_name" />
          </div>
        </div>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "Last name", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="text" name="surname" />
          </div>
        </div>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "Email", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="email" name="email" />
          </div>
        </div>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e('Role', 'adding-user-by-user'); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <label><input type="radio" name="role" id="role-employee" value="ubu_mitglied" /> <?php _e('Employee', 'adding-user-by-user'); ?></label>
            <label><input type="radio" name="role" id="role-trainee" value="ubu_azubi" /> <?php _e('Trainee', 'adding-user-by-user'); ?></label>
            <label><input type="radio" name="role" id="role-other" value="ubu_andere" /> <?php _e('Other', 'adding-user-by-user'); ?></label>

            <!-- <div class="aubu_field_other_role">
              <label><input type="radio" name="role" id="role-other" value="aubu_andere" /> <?php //_e('Other', 'adding-user-by-user'); ?></label>
              <input type="text" name="role" placeholder="<?php //_e('Type here...', 'adding-user-by-user'); ?>" style="display: none" />
            </div> -->

          </div>
        </div>

        <h3><?php _e( "Contact details", 'adding-user-by-user' ); ?></h3>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "guild", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="text" name="guild" />
          </div>
        </div>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "Road", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="text" name="street" />
          </div>
        </div>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "House number", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="text" name="house_no" />
          </div>
        </div>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "Post Code", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="text" name="postcode" />
          </div>
        </div>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "City", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="text" name="city" />
          </div>
        </div>

        <div class="aubu_single_field aubu_required">
          <div class="aubu_label">
            <label><?php _e( "Phone Number", 'adding-user-by-user' ); ?> <span>*</span></label>
          </div>
          <div class="aubu_field">
            <input type="text" name="phone" />
          </div>
        </div>

        <input type="submit" value="<?php _e( "Submit", 'adding-user-by-user' ); ?>" id="aubu-submit-btn"/>

      </form>
      <div class="aubu_submit_success_message" style="display: none">
        <p><?php _e( "The request to add users was successfully submitted to the website administrator. Please wait for approval.", 'adding-user-by-user' ); ?></p>
      </div>
    </div>
</div>
