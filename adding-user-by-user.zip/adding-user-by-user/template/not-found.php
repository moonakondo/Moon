<h2><?php _e('You are not authorized to see this page.', 'adding-user-by-user'); ?></h2>
