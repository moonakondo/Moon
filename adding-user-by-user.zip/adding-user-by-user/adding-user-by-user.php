<?php
/*
  Plugin Name: Adding User by User
  Description: Make an option to add user by another exists user
  Version: 1.1.2
  Text Domain: adding-user-by-user
  Domain Path: /languages
*/
// Prevent direct access
defined('ABSPATH') or die('Prevent direct access');

// Define some essectial constant
require_once( __DIR__ . '/config.php');

// Load autoloader
require_once AUBU_BASE_PATH . "vendor/autoload.php";

// use Activation class
use AUBU\Activation;
use AUBU\Register;
use AUBU\Shortcode;
use AUBU\REST_Controller;
use AUBU\Admin_Option;
use AUBU\DB_Table;
use AUBU\User_Profile;

if(! function_exists( 'aubu_plugin_activation' ) ) {
  // Do some plugin activation work
  register_activation_hook( __FILE__, 'aubu_plugin_activation' );

  function aubu_plugin_activation() {

    $activation = new Activation();

    // create table
    $activation->create_table();

    // create pages
    $activation->create_add_user_page();
    $activation->create_set_password_page();

  }
}

// Load text domain
include_once AUBU_BASE_PATH . 'load-text-domain.php';



class AUBU_Plugin {

  private static $instance = null;
  private static $db_table;

  function __construct() {
    // Load theme text domain
    add_action( 'plugins_loaded', array( $this, 'load_textdomain') );

    // Set JavaScript translation
    add_action( 'init', array( $this, 'set_script_translations' ) );

    // used to fix redirect warning/error
    ob_start();

    // Set outgoing email configuration
    add_action( 'wp_mail_content_type', array($this, 'set_email_content_type' ) );
    add_filter( 'wp_mail_from', array($this, 'email_sender_email') );
    add_filter( 'wp_mail_from_name', array($this, 'email_sender_name') );

    // Display the page state info
    add_filter('display_post_states', array($this, 'display_page_state'), 10, 2);

    // Profile fields
    new User_Profile();

    // Register Scripts and styles
    new Register();

    // Make shortcode
    new Shortcode( self::$db_table );

    // Register routes
    add_action( 'rest_api_init', array( $this, 'register_routes' ) );

    // Make some options in admin area
    new Admin_Option( self::$db_table );


  }

  function __destruct() {
    return ob_get_clean();
  }

  public static function getInstance(DB_Table $db_table) {
    self::$db_table = $db_table;
    if(self::$instance == null) {
      self::$instance = new AUBU_Plugin($db_table);
    }
    return self::$instance;
  }

  // display the state info of the plugin's page
  function display_page_state($post_states, $post) {
    if($post->post_name === AUBU_ADD_NEW_USER_PAGE_SLUG) {
      $post_states['aubu_add_new_user'] = __('Add a new user page', 'adding-user-by-user');
    }
    if($post->post_name === AUBU_SET_PASSWORD_PAGE_SLUG) {
      $post_states['aubu_set_password'] = __('Set Password page', 'adding-user-by-user');
    }
    return $post_states;
  }

  // Register Routes
  public function register_routes() {
      $controller = new REST_Controller();
      $controller->register_routes();
  }

  // Set email content type
  public function set_email_content_type() {
    return 'text/html';
  }
  // Set sender email address
  public function email_sender_email() {
    return AUBU_SENDER_EMAIL;
  }

  // Set sender name
  public function email_sender_name() {
    return AUBU_SENDER_NAME;
  }

}

add_action('init', function() {
  $db_table = new DB_Table();
  AUBU_Plugin::getInstance($db_table);
});
