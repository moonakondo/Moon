### Wordpress plugin to add user by another exist user
- https://stackoverflow.com/questions/15295853/how-to-filter-views-edit-in-user-list-table/15303126#15303126
