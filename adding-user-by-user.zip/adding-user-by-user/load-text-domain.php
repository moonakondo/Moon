<?php



// Load Textdomain
if( !function_exists( 'aubu_load_textdomain' ) ) {

  function aubu_load_textdomain() {
    load_plugin_textdomain( 'adding-user-by-user', false, AUBU_BASE_DIR_NAME . '/languages' );
  }

  add_action( 'plugins_loaded', 'aubu_load_textdomain' );

}


// Set Javascript Translation
if( !function_exists( 'aubu_set_script_translations' ) ) {

  function aubu_set_script_translations() {
    wp_set_script_translations(
      'aubu-frontend-add-user-js',
      'adding-user-by-user',
      plugin_dir_path( __FILE__ ) . 'languages'
    );
    wp_set_script_translations(
      'aubu-frontend-set-password-js',
      'adding-user-by-user',
      plugin_dir_path( __FILE__ ) . 'languages'
    );
  }
  add_action( 'wp_enqueue_scripts', 'aubu_set_script_translations', 101 );

}
