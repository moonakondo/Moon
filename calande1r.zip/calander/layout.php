<?php


add_action( 'add_meta_boxes', 'add_some_meta_box_valuations');
  
function add_some_meta_box_valuations()
{
    add_meta_box(
        'some_meta_box112233_namee'
       ,'Valuations Informations'
       ,'function_for_valuations_11'
       ,'post'
       ,'normal'
       ,'high'
    );

  }


  function function_for_valuations_11(){


    $name_atb_equity = get_post_meta($_GET['post'], "last_date_meta", true);   
    $fist_date = get_post_meta($_GET['post'], "first_date_meta", true);   
    ?>
    <input type="text" name="first_date" value="<?php echo  $fist_date; ?>">
    <input type="date" name="last_date" value="<?php echo $name_atb_equity; ?>">
    <?php
  }

  add_action("save_post", "save_meta_box_values_project", 10, 2);

function save_meta_box_values_project($post_id, $post) {
 

    $first_date = isset($_POST['first_date']) ? $_POST['first_date'] : "";
    $last_date = isset($_POST['last_date']) ? $_POST['last_date'] : "";

    update_post_meta($post_id, "last_date_meta", $last_date);
    update_post_meta($post_id, "first_date_meta", $first_date);

  }
