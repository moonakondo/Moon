<?php
/*
 * Plugin Name: calander
 */
// Enqueue FullCalendar scripts and styles
function enqueue_fullcalendar_scripts() {
    wp_enqueue_style('fullcalendar-css', 'https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.8.0/main.min.css');
    wp_enqueue_script('fullcalendar-js', 'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_fullcalendar_scripts');

include_once("layout.php");


// Fetch events from custom post type
function fetch_custom_post_type_events() {

    $args = array(
        'post_type' => 'post',
        'posts_per_page' => -1, // Get all posts
    );

    $events = array();

    $query = new WP_Query($args);
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
         
            $event = array(
                'title' =>  get_the_title(),
                'start' => get_post_meta(get_the_id(), "last_date_meta", true), // Adjust this based on your custom field names
                "Projrct_Manager"=>"Alif Islam",
                "description"=> 'Lecture'
                
                // Add more event details as needed
            );
            $events[] = $event;
       
        }
        wp_reset_postdata();
    }

    return $events;
}


#add_shortcode("fullwide_22", "fetch_custom_post_type_events" );

// Render FullCalendar

function render_fullcalendar() {

 ob_start();
    ?>

<div class="cl_main"  style="width:90%; margin:auto;">
  
  
  <div>

      <div class="cl_title"><h1>Events</h1></div>

      <div class="left">
        <div id="c_1"><h3 class="week_c">Week-1</h3></div>
        <div id="c_2"><h3 class="week_c">Week-2</h3></div>
        <div id="c_3"><h3 class="week_c">Week-3</h3></div>
        <div id="c_4"><h3 class="week_c">Week-4</h3></div>
        <div id="c_5"><h3 class="week_c">Week-5</h3></div>
        <div id="c_6"><h3 class="week_c">Week-6</h3></div>
      </div>
      <div class="right">
        <div id="calendar"></div>
      </div>

  </div>

</div>

<div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-body">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
<h3>Title</h3>
<h2 id="title_id"></h2>
<h3>Date</h3>
<h4 class="date"></h4>
<h3>Description</h3>
<h4 class="description"></h4>
<h4 class="description2"></h4>
</div>
</div>
</div>
</div>
</div>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script src="https://momentjs.com/downloads/moment.min.js"></script>

<style>
       .fc td, .fc th{
        border:none!important;
        padding: 2px 9px 7px 9px;
    }
    .modal-dialog {
    margin-top: 7%;
  }
  
  
  .fc-theme-standard .fc-scrollgrid{
    border:none;
  }
  .cl_main {
    border: 18px solid #66CCCC;
    border-radius: 18px;
  }
  .fc .fc-col-header-cell-cushion {
    display: inline-block;
    padding: 2px 4px;
    font-size: 20px;
    color: black;
  }
  
  .fc-scrollgrid-sync-inner {
    border: 2px solid yellow;
  }
  
  .fc-daygrid-day .fc-scrollgrid-sync-inner {
    border: 2px solid #66CCCC;
  }
  
  
  .fc-header-toolbar.fc-toolbar {
    display: none;
  }
  
  .cl_title {
    padding-left: 21px;
  }
  /* 
  .fc .fc-daygrid-day.fc-day-today {
    background-color: rgb(255 255 255 / 15%);
  } */
  
  
div#c_1 {
      height: 110px;
      position: absolute;
      top: 53%;
      border: 2px solid #66CCCC;
      margin-left: 5px;
  
  }
  
  
    .right {
      width: 95%;
      position: relative;
      left: 4%;
  }
  h3.week_c {
      transform: rotate(270deg);
      margin-top: 38px;
      font-size: 16px;
      margin-left: -9px;
  
      font-weight: 600;
  }
  
  div#c_2 {
      position: absolute;
      top: 75%;
      border: 2px solid #66CCCC;
      margin-left: 5px;
      height: 110px;
  }
  
  div#c_3{
    position: absolute;
      top: 96%;
      border: 2px solid #66CCCC;
      margin-left: 5px;
      height: 110px;
  }
  
  div#c_4{
    position: absolute;
      top: 117%;
      border: 2px solid #66CCCC;
      margin-left: 5px;
      height: 110px;
  }
  
  
  
  div#c_5{
    position: absolute;
      top: 139%;
      border: 2px solid #66CCCC;
      margin-left: 5px;
      height: 110px;
  }
  
  
  div#c_6{
    position: absolute;
      top: 160%;
      border: 2px solid #66CCCC;
      margin-left: 5px;
      height: 109px;
  }
  
  

  @media only screen and (max-width: 600px) {
  div#c_1 {
        height: 38px;
        position: absolute;
        top: 34%;
        border: 2px solid #66CCCC;
        margin-left: 5px;
    }

    h3.week_c{
    font-size: 8px;
    margin-top: 12px;
    margin-right: -6px;
    margin-left: -5px;

}

div#c_2 {
    position: absolute;
    top: 38%;
    border: 2px solid #66CCCC;
    margin-left: 5px;
    height: 38px;
    margin-top: 4px;
}

div#c_3 {
    position: absolute;
    top: 43%;
    border: 2px solid #66CCCC;
    margin-left: 5px;
    height: 38px;
}
.fc-daygrid-day .fc-scrollgrid-sync-inner {
    border: 2px solid #66CCCC;
    padding: 3px;
}
}






</style>





</style>
<script>

document.addEventListener('DOMContentLoaded', function() {
  var calendarEl = document.getElementById('calendar');
  var calendar = new FullCalendar.Calendar(calendarEl, {

    expandRows: true,
      slotMinTime: '08:00',
      slotMaxTime: '20:00',
      initialView: 'dayGridMonth',
      navLinks: true, // can click day/week names to navigate views
      editable: true,
      selectable: true,
      dayMaxEvents: true,

      columnHeaderText: 'Extra Column',

    firstDay: 1,





    events: <?php echo json_encode(fetch_custom_post_type_events()); ?>,




    
         eventClick: function(info) {
         jQuery("#successModal").modal("show");
         jQuery("#successModal .modal-body #title_id").text(info.event.title);
         jQuery("#successModal .modal-body .date").text(info.event.start);
         jQuery("#successModal .modal-body .description").text(info.event.extendedProps.description);
         jQuery("#successModal .modal-body .description2").text(info.event.extendedProps.Projrct_Manager);
         
        
         },

   
  });

  calendar.render();
});


</script>

    <?php
 return ob_get_clean();


}
add_shortcode('display_fullcalendar', 'render_fullcalendar');
