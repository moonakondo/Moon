 <?php 
  define('WP_USE_THEMES', false);
  if (file_exists("../../../wp-load.php"))
    {
    require_once("../../../wp-load.php");
    }
  
    unset($args);
    unset($s);
    unset($tax_query);
    $tax_query=array();
    if(!empty($_POST['team_category'])){
        $tax_query[] = array(
               'taxonomy' => 'team_cat',
               'field' => 'slug',
               'terms' => $_POST['team_category'],
            );
        }
    $s ='';
    if(!empty($_POST['keyword'])){
        $s = $_POST['keyword'];
        }
		
	$select_type = '';	
	if(!empty($_POST['select_type'])){
        $select_type = $_POST['select_type'];
        }
	 $OrderBY = '';	
	if(!empty($_POST['OrderBY'])){
        $OrderBY = $_POST['OrderBY'];
        }		
        
    $args =	array(
	            'orderby'   => 'meta_value',
                'order' => $OrderBY,
				'meta_type' => 'NUMERIC',
				'meta_key'=>$select_type,
                'post_per_page' 	=> -1,
                'post_type' 		=> 'surgerymedical',
				
				'meta_value' => ' ',
				'meta_compare' => '!=',
				'ignore_sticky_posts' => 1,
	
                's' => $s,
                'tax_query' => $tax_query,
                ); 
				
	if(empty($_POST['select_type'])){
		unset($args['order']);
		unset($args['meta_key']);
	}
	
    // The Query
    $the_query1 = new WP_Query( $args );
	//echo $the_query1->request;

    // The Loop
    if ( $the_query1->have_posts() ) {
       
        while ( $the_query1->have_posts() ) :
        $the_query1->the_post();

?>

<!--Here is the design of HTML This will show in our Front End //**Start**//-->
  <?php
     include(plugin_dir_path( __FILE__ ) . 'content.php');
  ?>

<!-- This is section two -->
<?php
	 endwhile;
      
    } 

    else {   

    }  
?>	