<?php
   set_time_limit(0);
   global $wpdb, $post;
   $sql = "SELECT * FROM wp_posts WHERE post_type LIKE 'surgerymedical' ORDER BY post_title ASC";
    $result = $wpdb->get_results($sql);

?>

<form method="post" action="admin.php?page=read_place_data" enctype="multipart/form-data">

    <?php
	  
	?>
    Company
    
    
    <select  name="company" style="width:500px">
     <?php
	   for($k=0;$k<count($result);$k++){
	 ?>
    
       <option value="<?php echo $result[$k]->post_title; ?>" <?php echo $_POST['company']==$result[$k]->post_title?'selected':'' ?>><?php echo $result[$k]->post_title; ?></option>
    
      <?php
	   }
	   ?>
    
    </select>
    <br>
    
    
    
    <div style="  border: 1px solid black;padding:5px;margin:5px;">    
    <h3>Update Google data</h3>
    <input type="submit" name="submit" value="Submit Selected" class="button  mt-4">

	<input type="submit" name="submit" value="Submit All" class="button  mt-4">
    </div>    
    <div style="  border: 1px solid black;padding:5px;margin:5px;">
      <h3>Import Comment</h3>
    <input type="file" name="file" class="button  mt-4">
    <input type="submit" name="import" value="Import" class="button  mt-4">
    <input type="submit" name="export" value="Export" class="button  mt-4">
    </div>
</form>


<?php
   if($_POST['submit']){
	  
	   if($_POST['submit']=='Submit All'){
		for($k=0;$k<count($result);$k++){
			$post_id = $result[$k]->ID;
            api_call(trim($result[$k]->post_title),$post_id);
		}
	   }else{
			$sql =  "SELECT * FROM wp_posts WHERE post_title LIKE '" .$_POST['company']."'";
			$result2 =  $wpdb->get_results($sql);
			$post_id = $result2[0]->ID;

			api_call(trim($_POST['company']),$post_id );

	   }
	  
   }
   
     require dirname(__FILE__) . '/vendor/autoload.php';

	  use PhpOffice\PhpSpreadsheet\Spreadsheet;
	  use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	  use PhpOffice\PhpSpreadsheet\Writer\Xls;
      
   if($_POST['import']){
	    $sql =  "SELECT * FROM wp_posts WHERE post_title LIKE '" .$_POST['company']."'";
		$result2 =  $wpdb->get_results($sql);
		$post_id = $result2[0]->ID;
		
		$file_picture = "";
		$created_at = date("Y-m-d H:i:s");	 
		$updated_at = "";
		if(isset($_FILES["file"]["name"]))
		{
			$path = $_FILES["file"]["tmp_name"]; 
			
			$arr_file 	= explode('.', $_FILES["file"]["name"]);
			$extension 	= end($arr_file);
			
			$reader=NULL;
			if('csv' == $extension) {     
			  $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
			} else if('xls' == $extension) {  
			  $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
			} else{     
			  $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
			} 
			
			$spreadsheet 	= $reader->load($path);
			$sheet_data 	= $spreadsheet->getActiveSheet()->toArray(); 
			
			
			for($row=1; $row<=count($sheet_data); $row++)
		    {
			    $company	 = isset($sheet_data[$row][0])?$sheet_data[$row][0]:'';
				$comment_author	 = isset($sheet_data[$row][1])?$sheet_data[$row][1]:'';
				$comment_author_email	 = isset($sheet_data[$row][2])?$sheet_data[$row][2]:'';
				$comment_author_url	 = isset($sheet_data[$row][3])?$sheet_data[$row][3]:'';
				$comment_content	 = isset($sheet_data[$row][4])?$sheet_data[$row][4]:'';
				$comment_date	 = isset($sheet_data[$row][5])?$sheet_data[$row][5]:'';
				if(!empty($comment_content)){
				$data = array(
					'comment_post_ID' => $post_id,
					'comment_author' => $comment_author,
					'comment_author_email' => $comment_author_email,
					'comment_author_url' => $comment_author_url	,
					'comment_content' => $comment_content,
					'comment_author_IP' => $_SERVER['REMOTE_ADDR'],
					'comment_agent' => $_SERVER['HTTP_USER_AGENT'],
					'comment_type'  => '',
					'comment_date' => date('Y-m-d H:i:s'),
					'comment_date_gmt' => date('Y-m-d H:i:s'),
					'comment_approved' => 1,
				);
				
				$comment_id = wp_insert_comment($data);
				}
				
			}
			echo "Insertion has been completed successfully";
		
		}
   }
   
   if($_POST['export']){
	    
	    $sql =  "SELECT * FROM wp_posts WHERE post_title LIKE '" .$_POST['company']."'";
		$result2 =  $wpdb->get_results($sql);
		$post_id = $result2[0]->ID;
		
		 
		$sql =  "SELECT * FROM wp_comments WHERE comment_post_ID= '" .$post_id."'";
		$obj_data =  $wpdb->get_results($sql);
		
		
		ob_start();		
		$table_columns[0] = array("company","comment_author","comment_author_email","comment_author_url","comment_content","comment_date");

		$spreadsheet = new Spreadsheet();
		  $sheet = $spreadsheet->getActiveSheet();
		
		  foreach($obj_data as $row)
		  {
		         $table_columns[] =  array($_POST['company'],
											$row->comment_author,
											$row->comment_author_email,
											$row->comment_author_url,
											$row->comment_content,
											$row->comment_date
								);
		    
		
	   }
	   
	             
	           $sheet->fromArray($table_columns, NULL, 'A1');   
			   
			    header('Content-Disposition: attachment;filename="comment.xls"');
                header('Cache-Control: max-age=0');
				
	            $writer = new Xls($spreadsheet);
				
				$writer->save("php://output");
				ob_end_clean();

				
   }


   function api_call($company,$post_id){
	$obj = file_get_contents('https://maps.googleapis.com/maps/api/place/textsearch/json?query='.urlencode(trim($company)).'&key=AIzaSyBXIGjRnb-tfybkf0BIQm2mX1RSXrs-BTE&');   
      
	 
	$obj = json_decode($obj); 
	$name_match = false; 
	for($i=0;$i<count($obj->results);$i++){
	   	if(strtolower($obj->results[$i]->name)==strtolower($company)){
			$obj->results[0] = $obj->results[$i];
			$name_match = true;
			continue;
		}
	}
	
	echo "<pre>";
	print_r($obj->results[0]);
	echo "</pre>";
	
	echo "Rating:";
	echo $obj->results[0]->rating;
	echo "<br>";
	$wse_ratting = $obj->results[0]->rating;

	 echo "user_ratings_total:";
	echo $obj->results[0]->user_ratings_total;
	echo "<br>";
	$wse_reviews = $obj->results[0]->user_ratings_total;
	
	 echo "formatted_address:";
	echo $obj->results[0]->formatted_address;
	echo "<br>";
	$name_atb_address =  $obj->results[0]->formatted_address;
	
	 echo "name:";
	echo $obj->results[0]->name;
	echo "<br>";
	
	 echo "icon:";
	echo $obj->results[0]->icon;
	echo '<img src="'.$obj->results[0]->icon.'" width="100">';
	echo "<br>";
	
	
	echo "place_id:";
	echo $obj->results[0]->place_id;
	echo "<br>";
	
	
	$url = 'https://maps.googleapis.com/maps/api/place/details/json?fields='.urlencode("name,rating,formatted_phone_number,opening_hours,reviews,website").'&place_id='.$obj->results[0]->place_id.'&key=AIzaSyBXIGjRnb-tfybkf0BIQm2mX1RSXrs-BTE&';
	$obj = file_get_contents($url);  
	$obj = json_decode($obj);  
	
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
	 echo "formatted_phone_number:";
	echo $obj->result->formatted_phone_number;
	echo "<br>";
	$name_atb_country = $obj->result->formatted_phone_number;


	echo "website:";
	echo $obj->result->website;
	echo "<br>";
	$name_atb_website = $obj->result->website;
	
	echo "weekday_text:";
	$arr =  $obj->result->opening_hours->weekday_text;
	for($i=0;$i<count((array)$arr);$i++)
	{
	  echo $arr[$i]."<br>";  
	}
	echo "<br>";
	
	
	  echo "reviews:";
	  $arr = $obj->result->reviews;
	  
	  for($i=0;$i<count($arr);$i++)
		{
		  echo $arr[$i]->author_name."<br>";  
		  echo $arr[$i]->author_url."<br>"; 
		  echo $arr[$i]->profile_photo_url."<br>"; 
		  echo $arr[$i]->relative_time_description."<br>"; 
		  echo $arr[$i]->text."<br>"; 
		  echo $arr[$i]->time."<br>"; 
		  echo "<br>"; 
		}
	  
	  echo "<br>";
		  if($name_match ==true){ 
			  if(!empty( $name_atb_address)){
				  update_post_meta($post_id, "_sm_surgerymedical_type", $name_atb_address);
			  }
			  //update_post_meta($post_id, "city", $name_atb_city);
			  if(!empty($name_atb_country)){
				  update_post_meta($post_id, "wse_country_meta_key", $name_atb_country);//phone no
			  }
			  if(!empty($wse_ratting)){
				  update_post_meta($post_id, "meta_ratting", $wse_ratting);
			  }
			  if(!empty( $name_atb_website)){
				  update_post_meta($post_id, "meta_website", $name_atb_website);//website
			  }
			  if(!empty( $wse_reviews)){
				  update_post_meta($post_id, "meta_reviews", $wse_reviews);
			  }
			  
			  echo "data has been updated";
	     }else{
			 echo "$company - Name mismatch.please update manually";
		 }

   }
   
?>