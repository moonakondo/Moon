<?php

// Add Shortcode
add_shortcode( 'sm-search-form', 'wse_sc_setup' );

function wse_sc_setup() {

    ob_start();
?>
    <style>
    label {
        display: block;
        margin: 10px 0 10px 0;
    }
    
    </style>
    <div id="primary" class="site-content">
    <div id="content" role="main">
    
            <form id="smform" action="<?=site_url('all-posts')?>" method="post" role="search">
				
                <section class="talk-section" style="margin-top:4%;">
      		    <div class="main-form">
                    <p>
                    <i class="fas fa-search first-icon" style="color:black;"></i>
                    <input type="text" class="key-filed" placeholder="Search for"; name="keyword" id="keyword" value="<?php echo (!empty($_POST['keyword']))? $_POST['keyword'] : ""; ?>" onBlur=" load_ajax();"/>
               
                		</input>
        
                    
                    </p>
                    <p>
                    	<i class="fas fa-map-marker first-icon"></i>
                        <input type="text" class="key-filed" placeholder="City"; name="team_category" id="team_category" value="<?php echo (!empty($_POST['team_category']))? $_POST['team_category'] : ""; ?>"  onBlur=" load_ajax();"/>
                    </p>
                    
           			 <br />
                     
                     <?php 
						  if(strtolower(get_the_title())==strtolower('Search Results')){
						?>
						
						  <p>
							
								 <select class="key-filed" name="select_type" id="select_type" onChange="load_ajax();">
								   <option value="">Select</option> 
								   <option value="city" <?php if (!empty($_POST['select_type']) && $_POST['select_type']=='city'){echo "selected";} ?>>Price</option>
								   <option value="meta_ratting" <?php if (!empty($_POST['select_type']) && $_POST['select_type']=='meta_ratting'){echo "selected";} ?>>Rating</option>
								   <option value="meta_reviews" <?php if (!empty($_POST['select_type']) && $_POST['select_type']=='meta_reviews'){echo "selected";} ?>>Reviews</option>
								 </select>
						   </p>
						   <p>
								 <select class="key-filed" name="OrderBY" id="OrderBY"  onChange="load_ajax();">
								   <option value="ASC" <?php if (!empty($_POST['OrderBY']) && $_POST['OrderBY']=='ASC'){echo "selected";} ?>>Low - High</option> 
								   <option value="DESC" <?php if (!empty($_POST['OrderBY']) && $_POST['OrderBY']=='DESC'){echo "selected";} ?>>High - Low</option>
								 </select>
							</p>
					   
					
						<?php
						  }
						 ?> 
            
                    <p class="main-ptag-searchbtn">
                        <button class="search-btn" type="submit" name="submit" value="This">
                        <i class="fas fa-search"></i>
                        </button>
                    </p>
        		</div>
             </section>
                
                
                
                
      
      
             
            
            
             
            
            
            
            </form>
            
  
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

           
<style>

.first-icon{
    position: absolute;
    margin-left:2%;
    margin-right:1%;
    margin-top: 14px;

}

.key-filed{
    padding-left: 17% !important;
    border-radius: 10px;
}
input.key-filed {
    border-radius: 15px;
    font-weight: 500;
}

.key-filed::placeholder{
font-size:16px;
color:black;


}


i.fas.fa-search {
    color: white;
}
i.fas.fa-search:hover{


}

button.search-btn {
    padding: 17px 26px;
    background:blue;
    border: none;
    border-radius: 14px;
}
button.search-btn:hover{
    background:blue;
    box-shadow: 3px 3px 17px #888888;
}


p .search-btn{

}
    .main-form p {
        margin-right: 10%;
    }
    .main-form{
        display:flex;
    }
	
@media only screen and (max-width: 600px) {
    .main-form{
     display:block;
     padding-right:7%;
     padding-left:7%;
     //text-align:center;
     }
	
	input.key-filed{
    width: 100%;
}
	
	button.search-btn{
		width:20%;
	}
	.main-form p {
     margin-right: 0;
}
	
	p.main-ptag-searchbtn {
    margin-top: -27px;
}
	
}

	
	
</style>




<?php

return ob_get_clean();

}