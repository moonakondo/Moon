<?php
/*
Plugin Name: WP Search Engine
Description: Search Medical Directories in Miami
Version:     1.5
Author:      Moon & Alif
Domain Path: wse
*/
?>
<?php

include_once 'add-shortcode.php';
include_once 'engine-pro.php';

// Main Post Type for Acomodation

function wse_surgerymedical_post_type() {

	$labels = array(
		'name'                  => _x( 'Surgery Medicals', 'Post Type General Name', 'surgerymedical-derectories' ),
		'singular_name'         => _x( 'surgerymedical Type', 'Post Type Singular Name', 'surgerymedical-derectories' ),
		'menu_name'             => __( 'Surgery Medical Derectories', 'surgerymedical-derectories' ),
		'name_admin_bar'        => __( 'Post Type', 'surgerymedical-derectories' ),
		'archives'              => __( 'Item Archives', 'surgerymedical-derectories' ),
		'attributes'            => __( 'Item Attributes', 'surgerymedical-derectories' ),
		'parent_item_colon'     => __( 'Parent Item:', 'surgerymedical-derectories' ),
		'all_items'             => __( 'All Surgery Medicals', 'surgerymedical-derectories' ),
		'add_new_item'          => __( 'Add New Surgery & Medical', 'surgerymedical-derectories' ),
		'add_new'               => __( 'Add Surgery Medical', 'surgerymedical-derectories' ),
		'new_item'              => __( 'New Item', 'surgerymedical-derectories' ),
		'edit_item'             => __( 'Edit Item', 'surgerymedical-derectories' ),
		'update_item'           => __( 'Update Item', 'surgerymedical-derectories' ),
		'view_item'             => __( 'View Item', 'surgerymedical-derectories' ),
		'view_items'            => __( 'View Items', 'surgerymedical-derectories' ),
		'search_items'          => __( 'Search Item', 'surgerymedical-derectories' ),
		'not_found'             => __( 'Not found', 'surgerymedical-derectories' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'surgerymedical-derectories' ),
		'featured_image'        => __( 'Featured Image', 'surgerymedical-derectories' ),
		'set_featured_image'    => __( 'Set featured image', 'surgerymedical-derectories' ),
		'remove_featured_image' => __( 'Remove featured image', 'surgerymedical-derectories' ),
		'use_featured_image'    => __( 'Use as featured image', 'surgerymedical-derectories' ),
		'insert_into_item'      => __( 'Insert into item', 'surgerymedical-derectories' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'surgerymedical-derectories' ),
		'items_list'            => __( 'Items list', 'surgerymedical-derectories' ),
		'items_list_navigation' => __( 'Items list navigation', 'surgerymedical-derectories' ),
		'filter_items_list'     => __( 'Filter items list', 'surgerymedical-derectories' ),
	
	);
	$args = array(
		'label'                 => __( 'surgerymedical Type', 'surgerymedical-derectories' ),
		'description'           => __( 'My surgerymedical Description', 'surgerymedical-derectories' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'comments', 'surgerymedical Options', 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',


	);
	
	register_post_type( 'surgerymedical', $args );

}

add_action( 'init', 'wse_surgerymedical_post_type', 0 );


// Register Custom Content Types

  //Add Team Types CPT
  add_action( 'init', 'create_cb_team_typesss' );

  function create_cb_team_typesss() {
	
	register_taxonomy('team_cat','surgerymedical',
	array(	
		'hierarchical' => true, 
		'label'=> 'Cities', 
		'query_var' => true, 
		'rewrite'=> true)
	
	);
	
	}

// Register Meta Boxes for Meta Fields
add_action( 'add_meta_boxes', 'wse_some_meta_box', 5 );

function wse_some_meta_box()
{
  
   
    add_meta_box(
        'wse_meta_box4_namee'
       ,'Location'
       ,'wse_meta_box_content_footer'
       ,'surgerymedical'
       ,'normal'
       ,'high'
    );
    

}



function wse_meta_box_content_footer($post){
 
?>

<label style="display:block; margin-top:3%;" for="wse_address">Address</label>
<?php $address = get_post_meta($post->ID, "_sm_surgerymedical_type", true) ?>
<input type="text" id="wse_address" value="<?php echo $address; ?>" name="name_atb_address">



<label style="display:block; margin-top:3%;" for="wse_city">Price</label>
<?php $city = get_post_meta($post->ID, "city", true) ?>
<input type="number" id="wse_city" value="<?php echo $city;?>" name="name_atb_city">

<label style="display:block; margin-top:3%;" for="wse_ratting">Rating</label>
<?php $ratting = get_post_meta($post->ID, "meta_ratting", true) ?>
<input type="text" id="wse_city" value="<?php echo $ratting;?>" name="wse_ratting">


<label style="display:block; margin-top:3%;" for="wse_reviews">Reviews</label>
<?php $ratting = get_post_meta($post->ID, "meta_reviews", true) ?>
<input type="number" id="wse_reviews" value="<?php echo $ratting;?>" name="wse_reviews">



<label style="display:block; margin-top:3%;" for="wse_country">Contact</label>
<?php $country = get_post_meta($post->ID, "wse_country_meta_key", true) ?>
<input type="text" id="wse_country" value="<?php echo $country;?>" name="name_atb_country">

<label style="display:block; margin-top:3%;" for="name_atb_website">Website URL</label>
<?php $country = get_post_meta($post->ID, "meta_website", true) ?>
<input type="text" id="name_atb_website" value="<?php echo $country;?>" name="name_atb_website">

<?php

}




// HTML fields are ended and functions for update meta are below 
function wse_save_meta_box_values($post_id, $post) {
    $name_atb_address = isset($_POST['name_atb_address']) ? $_POST['name_atb_address'] : "";
    $name_atb_city = isset($_POST['name_atb_city']) ? $_POST['name_atb_city'] : "";
    $name_atb_country = isset($_POST['name_atb_country']) ? $_POST['name_atb_country'] : "";
    $wse_ratting = isset($_POST['wse_ratting']) ? $_POST['wse_ratting'] : "";

    $name_atb_website = isset($_POST['name_atb_website']) ? $_POST['name_atb_website'] : "";

    $wse_reviews = isset($_POST['wse_reviews']) ? $_POST['wse_reviews'] : "";


    
// this code for update post meta connection to database

    update_post_meta($post_id, "_sm_surgerymedical_type", $name_atb_address);
    update_post_meta($post_id, "city", $name_atb_city);
    update_post_meta($post_id, "wse_country_meta_key", $name_atb_country);
    update_post_meta($post_id, "meta_ratting", $wse_ratting);
    update_post_meta($post_id, "meta_website", $name_atb_website);

    update_post_meta($post_id, "meta_reviews", $wse_reviews);
}




add_action("save_post", "wse_save_meta_box_values", 10, 2);



/**
 * Register custom query vars
 *
 * @link https://codex.wordpress.org/Plugin_API/Filter_Reference/query_vars
 */



function add_query_vars($public_query_vars) {
    $public_query_vars[] = 'city';
    return $public_query_vars;
}
add_filter('query_vars', 'add_query_vars');



/**
 * Build a custom query based on several conditions
 * The pre_get_posts action gives developers access to the $query object by reference
 * any changes you make to $query are made directly to the original object. No return value is requested
 *
 * @link https://codex.wordpress.org/Plugin_API/Action_Reference/pre_get_posts
 *
 */



function sm_pre_get_posts( $query ) {

 
    // check if the user is requesting an admin page 
    // or current query is not the main query
    if ( is_admin() || ! $query->is_main_query() ){
        return;
    }

    // edit the query only when post type is 'surgerymedical'
    // if it isn't, return
    if ( !is_post_type_archive( 'surgerymedical' ) ){
        return;
    }

    $meta_query = array();

    // add meta_query elements
    if( !empty( get_query_var( 'city' ) ) ){
        $meta_query[] = array( 'key' => '_sm_surgerymedical_city', 'value' => get_query_var( 'city' ), 'compare' => 'LIKE' );
    }


    if( count( $meta_query ) > 1 ){
        $meta_query['relation'] = 'AND';
    }

    if( count( $meta_query ) > 0 ){
        $query->set( 'meta_query', $meta_query );
    }
}

add_action( 'pre_get_posts', 'sm_pre_get_posts', 1 );


//ajax 
add_action('wp_print_scripts', 'ajax_load_scripts');
function ajax_load_scripts() {
			// load our jquery file that sends the $.post request
			wp_enqueue_script( "ajax", plugin_dir_url( __FILE__ ) . '/ajax.js', array( 'jquery' ) );
 
            // make the ajaxurl var available to the above script
			wp_localize_script( 'ajax', 'the_ajax_script', array( 'ajaxurl' => plugin_dir_url( __FILE__ ) . 'ajax-load.php' ) );
	
	wp_enqueue_script( 'my-js', 'https://code.jquery.com/jquery-3.7.0.js', false );

 
  }

// update Google data

  //Admin		
	add_action('admin_menu', 'read_google_place_data');
	function read_google_place_data(){
	  add_menu_page('Read Google Data', 'Read Google Data', 'manage_options', 'read_place_data', 'google_place_import_page_func');
	}
	 
	
	function google_place_import_page_func(){
		 include_once dirname(__FILE__) . '/admin_google_place_view.php';   
	}
	
