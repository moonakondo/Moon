<?php
// Add Shortcode
add_shortcode( 'sm-search-f', 'wse_sc_setup2' );
function wse_sc_setup2() {

    ob_start();
    ?>
    <?php
    unset($args);
    unset($s);
    unset($tax_query);
    $tax_query=array();
    if(!empty($_POST['team_category'])){
        $tax_query[] = array(
               'taxonomy' => 'team_cat',
               'field' => 'slug',
               'terms' => $_POST['team_category'],
            );
        }
    $s ='';
    if(!empty($_POST['keyword'])){
        $s = $_POST['keyword'];
        }
		
	$select_type = '';	
	if(!empty($_POST['select_type'])){
        $select_type = $_POST['select_type'];
        }
	 $OrderBY = '';	
	if(!empty($_POST['OrderBY'])){
        $OrderBY = $_POST['OrderBY'];
        }	
		
	
    $args =	array(
	            'orderby'   => 'meta_value',
                'order' => $OrderBY,
				'meta_key'=>$select_type,
                'post_per_page' 	=> -1,
                'post_type' 		=> 'surgerymedical',
				
				'meta_value' => ' ',
				'meta_compare' => '!=',
				'ignore_sticky_posts' => 1,
	
                's' => $s,
                'tax_query' => $tax_query,
                ); 
				
	if(empty($_POST['select_type'])){
		unset($args['order']);
		unset($args['meta_key']);
	}
	
    // The Query
    $the_query1 = new WP_Query( $args );
    // The Loop
    
	global $wpdb, $post;
		if($post->post_type == "surgerymedical"){
			
			echo "
			<style> 
				.ast-comment-list li{
				margin-top:3%;
				box-shadow: 0px 3px 10px #B9BAB4;
				background: #fff;
					border-radius: 10px;
				}
				
				

			header.ast-comment-meta.ast-row.ast-comment-author.vcard.capitalize {
			margin-left: 3%;
			}
			section.ast-comment-content.comment {
			padding: 1% 2%;
				}
				.ast-comment-avatar-wrap {
					padding: 3%;
				}
				.ast-comment-avatar-wrap img {	
				border-radius: 50%;
				}
				.timendate a {
				text-decoration: none;
				}
				img.icon-img {
					margin-top: -7% !important;
					}
		.site-header-primary-section-right.site-header-section.ast-flex.ast-grid-right-section {
			
        }
					h3.comments-title {
					font-size: 22px;
					font-weight: bold;
					text-align: center;
				}
					input#author {
			width: 100%;
					   }
					input#email {
					display: none;
								}
			</style>
			";
		}
		else{
			//Nothing
		}
	

?>

<!--Here is the design of HTML This will show in our Front End //**Start**//-->

<div id="id_content">

  <?php
       if ( $the_query1->have_posts() ) {
       
        while ( $the_query1->have_posts() ) :
              $the_query1->the_post();
              include(plugin_dir_path( __FILE__ ) . 'content.php');
	 
	    endwhile;
		   
		} 
	
		else {   
	
		}  
  ?>

</div>

<!-- This is section two -->

<style>


.row.talk-area {
    padding: 2.5%;
}
.about-img {
    padding: 2%;
}


.about-img img{
    width:350px;
    height:266px;
}

.star-icon{
    margin-left: 5%;  
}


.content-area1{
  margin-top: 1%;
    width: 55%;
  }
  .pending-btn{
    width: 45%;
    text-align: center;
    margin-top: 4%;
    margin-right: 3%;
    border-left: 2px solid #B9BAB4;
    margin-bottom: 6%;
  }



@media (max-width: 768px)
{

.mt-md-5 .about-text1 h2{
  margin-top: 5%;
}
}

.about-text1 h4{
  font-size: 15px;
  word-spacing: 3px;
  line-height: 20px;
}
.about-text1 h3{
  color: red;
  font-size: 20px;
}
.about-text1{
  display: flex;
}
.about-text1 h2{
font-size: 23px;
text-align: left;

  }

  .talk-area{
    padding: 1%;
    box-shadow: 0 0 16px rgba(109, 109, 109, 0.25);
  }

@media (min-width: 768px)
{
 .row .mt-md-5 {
    margin-top: 0px !important;
}
}

  .pending-btnn button{
    padding: 7px 11px;
    font-size: 13px;
    background-color: #FF002D;
    color: #fff;
    border-radius: 5px;
    font-weight: 600;

  }

  .pending-btn button{
    padding: 8px 11px;
    font-size: 16px;
    background-color: #FF002D;
    color: #fff;
    border-radius: 5px;
    font-weight: 600;
  }

*{
   font-family: Arial, Helvetica, sans-serif;
}

@media (max-width: 768px)
{
  .mt-md-5 .content-area1 h2{
    font-size: 16px;
	      font-weight: 400;
  }
  .mt-md-5 .content-area1 h3{
   font-size: 14px;
	  margin-top: 2% !important;
  }
  .mt-md-5 .content-area1 h4{
   font-size: 14px;
 font-weight: 400;
	  margin-top:2%;
  }
.mt-md-5  .pending-btn button{
  padding: 10px 35px;
}

}

</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">







<!--Here is the design of HTML This will show in our Front End //**End**//-->
              <?php 

   

 ?>
            </div><!-- #content -->
        </div><!-- #primary -->

    
<?php

return ob_get_clean();

}


// Register Query Var 

