// JavaScript Document
var jq = jQuery.noConflict();
//jQuery(document).ready( function($) {
function load_ajax(){	
    jq("#id_content").html("");		
 	//capture_date
	team_category = jq("#team_category").val();
	keyword = jq("#keyword").val();
	select_type = jq("#select_type").val();
	OrderBY = jq("#OrderBY").val();
	
	 var data = {   
	                ajax    : true,
					team_category   : team_category,
					keyword      : keyword,
					select_type     : select_type,
					OrderBY : OrderBY
				};
		
	jq.post(the_ajax_script.ajaxurl,
		   data, 
		   function(response) {
						jq("#id_content").html(response);
				 });
	//return false;
	
}
//});