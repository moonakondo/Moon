<section class="talk-section" style="margin-top:4%;">
  <div class="container">
    <div class="row talk-area">
      <div class="col-lg-4 col-md-12 col-12">
        <div class="about-img">
        <?php echo get_the_post_thumbnail(); ?> 
        </div>
      </div>
      <div class="col-lg-8 col-md-12 col-12 ps-lg-5 mt-md-5">
            <div class="about-text1">
              <div class="content-area1">
                <h2><?php the_title(); ?></h2>
                <h3>$<?php    global $post; $price = get_post_meta($post->ID, "city", true);
                    echo $price;
                    ?></h3>
                <h4><?php the_content(); ?></h4>
                <a href="<?php $current_url = get_permalink( get_the_ID() );
if( is_category() ) $current_url = get_category_link( get_query_var( 'cat' ) );
echo $current_url;?>
" class="pending-btnn" >
                  <button class="">Read More</button>
                </a>
            </div>
            <div class="pending-btn" style="color:#B9BAB4;">
             
                <div class="star-icon" style="display:inline-block">
                  <p style="display:inline-block;">( <?php $ratting = get_post_meta($post->ID, "meta_ratting", true);
                    echo $ratting;
                    ?>)</p>
                      <i class="fa-solid fa-star" style="color: #fab700;"></i>
                      <i class="fa-solid fa-star" style="color: #fab700;"></i>
                      <i class="fa-solid fa-star" style="color: #fab700;"></i>
                      <i class="fa-solid fa-star" style="color: #fab700;"></i>
                      <i class="fa-solid fa-star" style="color: #fab700;"></i>
					<a href="<?php $current_url = get_permalink( get_the_ID() );
if( is_category() ) $current_url = get_category_link( get_query_var( 'cat' ) );
echo $current_url;?>"><p style="display:inline-block;">Reviews</p></a>
					
                      <p style="display:inline-block;">(<?php $reviewes = get_post_meta($post->ID, "meta_reviews", true);
                    echo $reviewes;
                    ?>)</p>
                      <p style="text-align:left;color:#B9BAB4;font-size: 16px;">
                      City: <?php
                    global $post;
                    $terms = get_the_terms( $post->ID, 'team_cat' );
                    if ($terms) {
                        foreach($terms as $term) {
                            echo $term->name; ?> <br><?php
                        } 
                    }
                    ?>
                    </p>
                      <p style="text-align:left;color:#B9BAB4;font-size: 16px;">
                      Address: <?php $address = get_post_meta($post->ID, "_sm_surgerymedical_type", true);
                    echo $address;
                    ?>
                    </p>
                      <p style="text-align:left;color:#B9BAB4;font-size: 16px;">
                      Contact:
                      <?php $contact = get_post_meta($post->ID, "wse_country_meta_key", true);
                    echo $contact;
                    ?></p>
                    <a href="<?php $website = get_post_meta($post->ID, "meta_website", true);
                    echo $website;
                    ?>">
                    <p style="text-align:left;">
                    Visite Now <i class="fa-solid fa-globe"></i>
                    </p>
                    </a>
                    </div>
                    
              </div>
            </div>
      </div>
    </div>
  </div>
</section>