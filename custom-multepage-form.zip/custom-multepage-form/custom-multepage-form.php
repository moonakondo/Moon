<?php
/*
 * Plugin Name: Custom Multeple Form
 *  Version:    4.0
 */
 define( 'ZZCE_VERSION', '1.0');
 define("CMF_PLUHIN_PATH",plugin_dir_path(__FILE__));
 define("CMF_PLUHIN_LINK",plugin_dir_url(__FILE__));

 function css_and_js_link(){
    wp_enqueue_style( "cmf-css" , CMF_PLUHIN_LINK."css/style.css",array(), );
    wp_enqueue_script( "cmf-js" , CMF_PLUHIN_LINK."js/custom.js",array("jquery"));
 }

 add_action("wp_enqueue_scripts","css_and_js_link");

 add_action( "admin_menu", "main_menu" );
 function main_menu(){
     add_menu_page( "Multiple Form Data", "Multiple Form Data","manage_options", "mulple-form-data", "main_callback", "dashicons-admin-users",1 );
 
     add_submenu_page("mulple-form-data","View","Multiple Form Data","manage_options","mulple-form-data","main_callback");
 
 }



 function main_callback(){
  
	 ?>
<h2>
	Use this shortcode = [multple-form-layout]
</h2>
<?php
 }

// First we register our resources using the init hook
function ZZCE_resources() {
	wp_register_script("ZZCE-script", plugins_url("js/main.js", __FILE__), array('jquery'), ZZCE_VERSION, false);
	wp_register_style("ZZCE-style",  plugins_url("css/styles.css", __FILE__) , array(), ZZCE_VERSION, "all");
}
add_action( 'init', 'ZZCE_resources' );

function ZZCE_func( $attr , $content) {
	wp_enqueue_script('jquery');
	
	$nonce = wp_create_nonce( 'ZZCE_nonce' );
	wp_localize_script( 'ZZCE-script', 'ZZCE_var', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) , 'nonce' => $nonce ) );
	wp_enqueue_style("ZZCE-style");
	ob_start();
	include plugin_dir_path( __FILE__ ) . "/add-form-data.php";
	$myvar = ob_get_clean();
	
	return $myvar;
}

add_shortcode('multple-form-layout', 'ZZCE_func');

// sendemail AJAX
add_action( 'wp_ajax_ZZCE_sendmail', 'ZZCE_sendmail' );
add_action( 'wp_ajax_nopriv_ZZCE_sendmail', 'ZZCE_sendmail' );
function ZZCE_sendmail() {
	check_ajax_referer( 'ZZCE_nonce' , '_ajax_nonce' );
	
	//SEND EMAIL TO USER
	
		//$email_user = sanitize_email($_POST["email_user"]);
		$title_user = sanitize_text_field($_POST["title_user"]);
		$phone_user = sanitize_text_field($_POST["phone_user"]);
		$image_user = sanitize_text_field($_POST["image_user"]);
		$image_user_g2 = sanitize_text_field($_POST["image_user_s2"]);
		$image_user_g3 = sanitize_text_field($_POST["image_user_s3"]);
		$image_user_g4 = sanitize_text_field($_POST["image_user_s4"]);
		$image_user_g5 = sanitize_text_field($_POST["image_user_s5"]);
		$image_user_g6 = sanitize_text_field($_POST["image_user_s6"]);
		$image_user_g7 = sanitize_text_field($_POST["image_user_s7"]);
		$image_user_g8 = sanitize_text_field($_POST["image_user_s8"]);
		$image_user_g9 = sanitize_text_field($_POST["image_user_s9"]);
		$image_user_g10 = sanitize_text_field($_POST["image_user_s10"]);
		$image_user_g11 = sanitize_text_field($_POST["image_user_s11"]);
		$image_user_g12 = sanitize_text_field($_POST["image_user_s12"]);
		$image_user_g13 = sanitize_text_field($_POST["image_user_s13"]);
		$image_user_g14 = sanitize_text_field($_POST["image_user_s14"]);
		$image_user_g15 = sanitize_text_field($_POST["image_user_s15"]);
		$image_user_g16 = sanitize_text_field($_POST["image_user_s16"]);
		$image_user_g17 = sanitize_text_field($_POST["image_user_s17"]);
		$image_user_g18 = sanitize_text_field($_POST["image_user_s18"]);
			$image_user_g19 = sanitize_text_field($_POST["image_user_s19"]);
		$image_user_g20 = sanitize_text_field($_POST["image_user_s20"]);
	$image_user_g21 = sanitize_text_field($_POST["image_user_s21"]);
		$image_user_g22 = sanitize_text_field($_POST["image_user_s22"]);
	
	
	

		add_filter('wp_mail_content_type', function( $content_type ) {
            return 'text/html';
		});
		$to = 'uczayxhg@robot.zapier.com';
		$subject = 'Multepage form Information : User Info';
		$body = '<html>
			<body>
				<table>
					<tr>
						<td><b>
						Name 
						</b>
						<br>'. $title_user .'</td> 
					</tr>

					<tr>
					<td><b>
					מה השווי המשוער של כספי החסכונות וקופות הגמל שלך ושל משפחתך? </b><br>'
			. $image_user 
			.$image_user_g2.
			$image_user_g3.
			$image_user_g4.
			'</td>
				</tr>
				
					<tr>
					<td><b>
					באילו בתי השקעות מנוהלות קרנות ההשתלמות ו/או קופות הגמל שלך היום?
					</b>
 <br>'
			. $image_user_g5 
			.$image_user_g6.
			$image_user_g7.
			$image_user_g8.
			$image_user_g9.
			$image_user_g10.
			$image_user_g11.
			$image_user_g12.
			$image_user_g13.
			$image_user_g14.
			'</td>
				</tr>
				
							<tr>
					<td><b>
מה השווי המשוער של כספי החסכונות וקופות הגמל שלך ושל משפחתך?
</b>
 <br>'
			. $image_user_g15 
			.$image_user_g16.
			$image_user_g17.
			$image_user_g18.
			'</td>
				</tr>
				
				
											<tr>
					<td>
בדיקת הגדלת תשואה בקרן ההשתלמות
 <br>'
			. $image_user_g19 
			.$image_user_g20.
			$image_user_g21.
			$image_user_g22.
			'</td>
				</tr>
				
				
				
				
				
				
				
				
					<tr>
						<td><b>Phone Number</b><br> '. $phone_user .'</td> 
					</tr>
					
				</table>
			</body>
		</html>';
		$headers = array('Content-Type: text/html; charset=UTF-8');
		
		if (($title_user)&&($phone_user)) {
			$success_user = wp_mail( $to, $subject, $body, '', array( '' ) );
			if ($success_user) {
				echo '<div class="zz-success"><h2>Thank you for your information</h1></div>';
			} else {
				echo '<div class="zz-failed"> failed. Please try again</div>';
			}
		} 
		$aStr = "";
		
		if (!$title_user) {
			$aStr = $aStr . '<div class="zz-failed">You must fill Type your name</div>';
		}
		if (!$phone_user) {
			$aStr = $aStr . '<div class="zz-failed">You must fill your phone Number</div>';
		}

	
	
	
	
		if ($aStr) {
			echo $aStr;
		}
		wp_die();
}
	
