<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<!-- MultiStep Form -->


<div >
<div class="row">
    <div class="col-md-6 col-md-offset-3 bg-danger">
        <form id="msform" name="xcxcxc">
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active"></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>
            <!-- fieldsets -->
            <fieldset class="fieldset_1">
            <img fetchpriority="high" decoding="async" class="image" src="https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול.png" class="attachment-full size-full wp-image-67" alt="" srcset="https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול.png 800w, https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול-300x127.png 300w, https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול-768x325.png 768w" sizes="(max-width: 16px) 100vw, 800px">
                <h2 class="fs-title ">בדיקת הגדלת תשואה בקרן ההשתלמות</h2>
                <figure class="wp-block-image size-large is-resized tevel"><img decoding="async" src="https://pascall.co.il/wp-content/uploads/2023/06/My-project-1-1.png" alt="" style="object-fit:contain;width:150px;height:150px" width="150" height="150"></figure>
                <h2 class="fs-title2 ">נעים מאוד, שמי תבל</h2>
                <h2 class="fs-title2 ">אשמח לבדוק את זכאותך לשדרוג קרן ההשתלמות / קופת גמל שלך.</h2>
                <h2 class="fs-title2 "> שנצא לדרך?</h2>
                <h2 class="fs-titlelast "> מהו שמך?</h2>
              	<input type="text" id="title-user" class="name" name="sdfsfs" value="" placeholder="מספר נייד תקני" required> 
                <input dir="rtl"  type="button" name="next" class="next action-button" value="בדוק זכאות עכשיו >>"/>
                <p style="font-size:16px; font-weight:700">
                [מעל 47,622 ישראלים שצברו מעל 300 אלף ₪ כבר ביצעו בדיקת זכאות לשיפור התשואות והוזלת דמי הניהול בקרן ההשתלמות שלהם]
                </p>

                <div>
                <span dir="rlt">טופס פרטי ומאובטח <img src="<?php echo CMF_PLUHIN_LINK; ?>img/Screenshot 2024-02-16 at 14-37-08 שאלון קרנות השתלמות - פסקול.png" width="35"></span>
                <span dir="rlt">תנאי שימוש<img src="<?php echo CMF_PLUHIN_LINK; ?>img/Screenshot 2024-02-16 at 14-37-49 שאלון קרנות השתלמות - פסקול.png" width="35"></span>
                </div>
            </fieldset>

            <fieldset class="fieldset_2">
            <img fetchpriority="high" decoding="async" class="image" src="https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול.png" class="attachment-full size-full wp-image-67" alt="" srcset="https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול.png 800w, https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול-300x127.png 300w, https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול-768x325.png 768w" sizes="(max-width: 16px) 100vw, 800px">
                <h2 class="fs-title ">בדיקת הגדלת תשואה בקרן ההשתלמות</h2>
                <figure class="wp-block-image size-large is-resized tevel"><img decoding="async" src="https://pascall.co.il/wp-content/uploads/2023/06/My-project-1-1.png" alt="" style="object-fit:contain;width:150px;height:150px" width="150" height="150"></figure>
                <h2 class="fs-title2 " dir="rtl">מה השווי המשוער של כספי החסכונות וקופות הגמל שלך ושל משפחתך?</h2>


                <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div id="temp_2_box" class="box">
                 
                        <img id="image_1" src="<?php echo CMF_PLUHIN_LINK; ?>img/monry_1.png" width="140" />
                     
                        <input type="checkbox" class="chk " id="old_1" name="img1" value="עד 150,000 ₪" />
				
                        <h5 dir="rtl">עד 150,000 ₪</h5>
				
                    </div>
                    </a>
              
                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div id="temp_2_box_1" class="box">
			
                        <img id="image_2" class="height_img"src="<?php echo CMF_PLUHIN_LINK; ?>img/money_2.png" width="140">
				
						   <input type="checkbox" class="chk " id="old_2" name="" value="בין 150 אלף - 300,000 ₪" />
                        <h5 dir="rtl" class="height_p"> בין 150 אלף - 300,000 ₪ </h5>
                    </div>
                    </a>

                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div id="temp_2_box_2 responsive" class="box">
                        <img  id="image_3" class="image_hei"src="<?php echo CMF_PLUHIN_LINK; ?>img/money_3.jpg" width="140">
						  <input type="checkbox" class="chk " id="old_3" name="" value="בין 150 אלף - 300,000 ₪" />
                        <h5 dir="rtl">בין 300 אלף - 1 מיליון ₪</h5>
                    </div>
                    </a>
                  
                   
                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div id="temp_2_box_3" class="box">
                        <img  id="image_4" src="<?php echo CMF_PLUHIN_LINK; ?>img/money_4.png" width="140">
						 <input type="checkbox" class="chk " id="old_4" name="" value="                        1 מיליון ₪ ומעלה
" />
                        <h5  dir="rtl">1 מיליון ₪ ומעלה</h5>
                     </div>

                   </a>

                   <input dir="rtl" type="button" name="nexto" class=" action-button" value="הבא >>"/>
          <input dir="rtl" type="button" id="number_two" name="previous" class="previous action-button-previous" value="<< חזרה לעמוד הקודם" />
         
          <p style="font-size:16px; font-weight:700">
                [מעל 47,622 ישראלים שצברו מעל 300 אלף ₪ כבר ביצעו בדיקת זכאות לשיפור התשואות והוזלת דמי הניהול בקרן ההשתלמות שלהם]
                </p> 
          <div>
                <span dir="rlt">טופס פרטי ומאובטח <img src="<?php echo CMF_PLUHIN_LINK; ?>img/Screenshot 2024-02-16 at 14-37-08 שאלון קרנות השתלמות - פסקול.png" width="35"></span>
                <span dir="rlt">תנאי שימוש<img src="<?php echo CMF_PLUHIN_LINK; ?>img/Screenshot 2024-02-16 at 14-37-49 שאלון קרנות השתלמות - פסקול.png" width="35"></span>
                </div>
            </fieldset>
            <fieldset class="main_fieldset  fieldset_3" >
            <img fetchpriority="high" decoding="async" class="image" src="https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול.png" class="attachment-full size-full wp-image-67" alt="" srcset="https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול.png 800w, https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול-300x127.png 300w, https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול-768x325.png 768w" sizes="(max-width: 16px) 100vw, 800px">
                <h2 class="fs-title ">בדיקת הגדלת תשואה בקרן ההשתלמות</h2>
                <figure class="wp-block-image size-large is-resized tevel"><img decoding="async" src="https://pascall.co.il/wp-content/uploads/2023/06/My-project-1-1.png" alt="" style="object-fit:contain;width:150px;height:150px" width="150" height="150"></figure>
                <h2 class="fs-title2" dir="rtl">באילו בתי השקעות מנוהלות קרנות ההשתלמות ו/או קופות הגמל שלך היום?</h2>



    
            <a href="javascipt:invoid(0)"  name="next" class="next ">
                   <div class="box" id="tem_3_box_none">
                        <img id="image_5" src="<?php echo CMF_PLUHIN_LINK; ?>img/company_1.png" width="140">
					<input type="checkbox" class="chk " id="old_5" name="" value="אלטשולר" />
                        <h5  dir="rtl">אלטשולר</h5>
                    </div>
                    </a>

                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="tem_3_box_2">
                        <img id="image_6" src="<?php echo CMF_PLUHIN_LINK; ?>img/company_2.png" width="140">
						<input type="checkbox" class="chk " id="old_6" name="" value="אלטשולר" />
                        <h5 dir="rtl">הפניקס</h5>
                    </div>
                    </a>

                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="tem_3_box_3 left1">
                        <img id="image_7" src="<?php echo CMF_PLUHIN_LINK; ?>img/company_3.png" width="140">
						<input type="checkbox" class="chk " id="old_7" name="" value="הראל" />

                        <h5 dir="rtl">הראל</h5>
                    </div>
                    </a>

                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="tem_3_box_4">
                        <img id="image_8" src="<?php echo CMF_PLUHIN_LINK; ?>img/company_4.png" width="140">
						<input type="checkbox" class="chk " id="old_8" name="" value="מנורה" />
                        <h5 dir="rtl">מנורה</h5>
                    </div>
                    </a>

                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="tem_3_box_left">
                        <img id="image_9" src="<?php echo CMF_PLUHIN_LINK; ?>img/company_5.png" width="140">
						<input type="checkbox" class="chk " id="old_9" name="" value="מגדל" />
                        <h5 dir="rtl">מגדל</h5>
                    </div>
                    </a>
                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="tem_3_box_6">
                        <img id="image_10" src="<?php echo CMF_PLUHIN_LINK; ?>img/company_6.png" width="140">
							<input type="checkbox" class="chk " id="old_10" name="" value="מגדל" />
                        <h5 dir="rtl">כלל</h5>
                    </div>
                    </a>
                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="tem_3_box_7 left1">
                        <img id="image_11" src="<?php echo CMF_PLUHIN_LINK; ?>img/company_7.png" width="140">
						<input type="checkbox" class="chk " id="old_11" name="" value="מור" />
						
                        <h5 dir="rtl">מור</h5>
                    </div>
                    </a>

                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="tem_3_box_8">
                        <img id="image_12" src="<?php echo CMF_PLUHIN_LINK; ?>img/company_8.png" width="140">
						<input type="checkbox" class="chk " id="old_12" name="" value="מיטב דש" />
                        <h5 dir="rtl">מיטב דש</h5>
                    </div>
                    </a>

            
            <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box nine" id="tem_3_box_9">
                        <img  id="image_13" src="<?php echo CMF_PLUHIN_LINK; ?>img/company_9.png" width="140">
						<input type="checkbox" class="chk " id="old_13" name="" value="אחר" />
                        <h5 dir="rtl">אחר</h5>
                    </div>
                    </a>
                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="tem_3_box_10">
                        <img  id="image_14" src="<?php echo CMF_PLUHIN_LINK; ?>img/company_10.png" width="140">
							<input type="checkbox" class="chk " id="old_14" name="" value="אקסלנט" />
                        <h5 dir="rtl">אקסלנט</h5>
                    </div>
                    </a>
          
           
                    <input dir="rtl" type="button" name="nexto" class=" action-button" value="הבא >>"/>
          <input dir="rtl" type="button" id="number_two" name="previous" class="previous action-button-previous" value="<< חזרה לעמוד הקודם" style="font-size: 27px ;"/>
            <p style="font-size:16px; font-weight:700">
                [מעל 47,622 ישראלים שצברו מעל 300 אלף ₪ כבר ביצעו בדיקת זכאות לשיפור התשואות והוזלת דמי הניהול בקרן ההשתלמות שלהם]
                </p>
            <div>
                <span dir="rlt">טופס פרטי ומאובטח <img src="<?php echo CMF_PLUHIN_LINK; ?>img/Screenshot 2024-02-16 at 14-37-08 שאלון קרנות השתלמות - פסקול.png" width="35"></span>
                <span dir="rlt">תנאי שימוש<img src="<?php echo CMF_PLUHIN_LINK; ?>img/Screenshot 2024-02-16 at 14-37-49 שאלון קרנות השתלמות - פסקול.png" width="35"></span>
                </div>   
             
            </fieldset>
            <fieldset class=" fieldset_4" >
            <img fetchpriority="high" decoding="async" class="image" src="https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול.png" class="attachment-full size-full wp-image-67" alt="" srcset="https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול.png 800w, https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול-300x127.png 300w, https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול-768x325.png 768w" sizes="(max-width: 16px) 100vw, 800px">
                <h2 class="fs-title ">בדיקת הגדלת תשואה בקרן ההשתלמות</h2>
                <figure class="wp-block-image size-large is-resized tevel"><img decoding="async" src="https://pascall.co.il/wp-content/uploads/2023/06/My-project-1-1.png" alt="" style="object-fit:contain;width:150px;height:150px" width="150" height="150"></figure>
                <h2 class="fs-title2 ">מה השווי המשוער של כספי החסכונות וקופות הגמל שלך ושל משפחתך?</h2>



                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="temp_2_box">
                        <img id="image_15" src="<?php echo CMF_PLUHIN_LINK; ?>img/parent_1.png" width="183">
						<input type="checkbox" class="chk " id="old_15" name="" value="66+" />
                        <h5 dir="rtl">66+</h5>
                    </div>
                    </a>

                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="tem_4_box_2">
                        <img id="image_16" src="<?php echo CMF_PLUHIN_LINK; ?>img/parent_2.png" width="183">
						<input type="checkbox" class="chk " id="old_16" name="" value="50-65" />
                        <h5 dir="rtl">50-65</h5>
                    </div>
                    </a>
                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="tem_4_box_3 ress">
                        <img id="image_17" src="<?php echo CMF_PLUHIN_LINK; ?>img/parent_3.png" width="183">
						<input type="checkbox" class="chk " id="old_17" name="" value="23-49" />
                        <h5 dir="rtl">23-49</h5>
                    </div>
                    </a>
                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div class="box" id="tem_4_box_4">
                        <img id="image_18" src="<?php echo CMF_PLUHIN_LINK; ?>img/parent_4.png" width="183">
						<input type="checkbox" class="chk " id="old_18" name="" value="23 עד" />
                        <h5  dir="rtl">עד 23</h5>
                    </div>
                    </a>

        
                    <input dir="rtl" type="button" name="nexto" class=" action-button" value="הבא >>"/>
          <input dir="rtl" type="button" id="number_two" name="previous" class="previous action-button-previous" value="<< חזרה לעמוד הקודם" style="font-size: 27px ;"/>
                <p style="font-size:16px; font-weight:700">
                [מעל 47,622 ישראלים שצברו מעל 300 אלף ₪ כבר ביצעו בדיקת זכאות לשיפור התשואות והוזלת דמי הניהול בקרן ההשתלמות שלהם]
                </p>
                <div>
                <span dir="rlt">טופס פרטי ומאובטח <img src="<?php echo CMF_PLUHIN_LINK; ?>img/Screenshot 2024-02-16 at 14-37-08 שאלון קרנות השתלמות - פסקול.png" width="35"></span>
                <span dir="rlt">תנאי שימוש<img src="<?php echo CMF_PLUHIN_LINK; ?>img/Screenshot 2024-02-16 at 14-37-49 שאלון קרנות השתלמות - פסקול.png" width="35"></span>
                </div>   
             
            </fieldset>
            <fieldset class="fieldset_5" >
            <img fetchpriority="high" decoding="async" class="image" src="https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול.png" class="attachment-full size-full wp-image-67" alt="" srcset="https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול.png 800w, https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול-300x127.png 300w, https://pascall.co.il/wp-content/uploads/2023/02/לוגו-פסקול-768x325.png 768w" sizes="(max-width: 16px) 100vw, 800px">
                <h2 class="fs-title ">בדיקת הגדלת תשואה בקרן ההשתלמות</h2>
                <figure class="wp-block-image size-large is-resized tevel"><img decoding="async" src="https://pascall.co.il/wp-content/uploads/2023/06/My-project-1-1.png" alt="" style="object-fit:contain;width:150px;height:150px" width="150" height="150"></figure>
                <h2 class="fs-title2 ">מה השווי המשוער של כספי החסכונות וקופות הגמל שלך ושל משפחתך?</h2>


                <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div id="temp_2_box" class="box">
                        <img id="image_19"  src="<?php echo CMF_PLUHIN_LINK; ?>img/south.png" width="183">
							<input type="checkbox" class="chk " id="old_19" name="" value="דרום" />
                        <h5 dir="rtl">דרום</h5>
                    </div>
                    </a>
                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div id="temp_2_box_1" class="box">
                        <img id="image_20"  src="<?php echo CMF_PLUHIN_LINK; ?>img/north.png" width="183">
							<input type="checkbox" class="chk " id="old_20" name="" value="צפון" />
                        <h5 dir="rtl">צפון</h5>
                    </div>
                    </a>

                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div id="temp_2_box_2 ress" class="box">
                        <img id="image_21" src="<?php echo CMF_PLUHIN_LINK; ?>img/lowland.png" width="183">
						<input type="checkbox" class="chk " id="old_21" name="" value="שפלה" />
                        <h5 dir="rtl">שפלה</h5>
                    </div>
                    </a>
                  
                   
                    <a href="javascipt:invoid(0)"  name="next" class="next ">
                    <div id="temp_2_box_3" class="box">
                        <img id="image_22" src="<?php echo CMF_PLUHIN_LINK; ?>img/coordinator.png" width="183">
							<input type="checkbox" class="chk " id="old_22" name="" value="מרכז" />
                        <h5  dir="rtl">מרכז</h5>
                     </div>

                   </a>

                   <input dir="rtl" type="button" name="nexto" class=" action-button" value="הבא >>"/>
          <input dir="rtl" type="button" id="number_two" name="previous" class="previous action-button-previous" value="<< חזרה לעמוד הקודם" style="font-size: 27px ;"/>
              
                <p style="font-size:16px; font-weight:700">
                [מעל 47,622 ישראלים שצברו מעל 300 אלף ₪ כבר ביצעו בדיקת זכאות לשיפור התשואות והוזלת דמי הניהול בקרן ההשתלמות שלהם]
                </p>
                <div>
                <span dir="rlt">טופס פרטי ומאובטח <img src="<?php echo CMF_PLUHIN_LINK; ?>img/Screenshot 2024-02-16 at 14-37-08 שאלון קרנות השתלמות - פסקול.png" width="35"></span>
                <span dir="rlt">תנאי שימוש<img src="<?php echo CMF_PLUHIN_LINK; ?>img/Screenshot 2024-02-16 at 14-37-49 שאלון קרנות השתלמות - פסקול.png" width="35"></span>
                </div>   
            </fieldset>



<!-- =====================Last Section ==================-->



<fieldset  class="fieldset_6">
            
                <figure class="wp-block-image size-large is-resized tevel"><img decoding="async" src="https://pascall.co.il/wp-content/uploads/2023/06/My-project-1-1.png" alt="" style="object-fit:contain;width:150px;height:150px" width="150" height="150"></figure>
                <h2 class="fs-title2 ">מעולה, כמעט סיימנו!</h2>
                <h2 class="fs-title2 ">גלה את תוצאות הבדיקה לאחר אימות שאינך רובוט.</h2>
                <!-- <h2 class="fs-title2 "> שנצא לדרך?</h2> -->

                <h2 class="fs-titlelast "> מהו שמך?</h2>
              	<input type="text" name="question" class="name" id="phone-user"  placeholder="מספר נייד תקני" required /> 
           

	<label class="jet-form-builder__field-label for-checkbox" data-gtm-vis-recent-on-screen119441222_28="30324" data-gtm-vis-first-on-screen119441222_28="30324" data-gtm-vis-total-visible-time119441222_28="100" data-gtm-vis-has-fired119441222_28="1" data-gtm-vis-first-on-screen119441222_207="30333" data-gtm-vis-total-visible-time119441222_207="100" data-gtm-vis-has-fired119441222_207="1">

		<p id="text" style="display:none; text-align:left;paddling:0; margin:0;color: red;font-size: 13px;">נא למלא את השדה.
</p>
		<span><p class='span6' style=" float:left;">אני מאשר שקראתי ומסכים <a href=" " class="PrivacyPolicy"> לתנאי השימוש והפרטיות, </a> וכי הפרטים שמסרתי ישמשו לקבלת פניות מאיתנו או מצד שלישי הכולל שיווק מוצרי ביטוח.</p></span>
	
	<input style="float:left;"type="checkbox" value="כן" id='myCheck' onclick="myFunction()" class="cb" required="required">
	
	</label>
	
	<a href="https://relevanty.co.il/thank-you/">
            <input   type="button" id="zz-submit-email"  onclick="return IsEmpty();"  class="action-button lastb" value="בדוק זכאות עכשיו >>" disabled='disabled'/> 
       </a>
                
            </fieldset>
            
         
         
        </form>
     
    </div>
</div>
</div>

<script>
function myFunction() {
  var checkBox = document.getElementById("myCheck");
  var text = document.getElementById("text");
  if (checkBox.checked == true){
 
	     text.style.display = "none";
  } else {
       text.style.display = "block";
  }
}
</script>
<script type="text/javascript">
$('#check').click(function() {
  if ($(this).is(':checked')) {
    $('#zz-submit-email').removeAttr('disabled');
  } else {
    $('#zz-submit-email').attr('disabled', 'disabled');
  }
});
</script>

<!--====Code for Responsive=== -->
<style>

	
	.span6{
		width:97%;
	}
.cb{
		width:3%!important;
	}
#number_two {
padding: 15px 50px 15px 50px!important;
}

@media only screen and (max-width: 2000px) {
    .box {
        width: 13%;
        height: 175px; 
}
div#temp_2_box {
    margin-left: 20%;
}

div#tem_3_box_none {
    margin-left: 20%;
}
div#tem_3_box_left {
    margin-left: 20%;
}
div#tem_3_box_10 {
    margin-right: 12%;
}

.fieldset_5 .box {

    width: 13%;
    height: 134px;

}

}
@media only screen and (max-width: 900px) {

    div#tem_3_box_10 {
    margin-right: 0%;
}

    div#tem_3_box_none {
    margin-left: 13%;
}
div#tem_3_box_left {
    margin-left: 13%;
}



    div#temp_2_box {
    margin-left: 13%;
}
    #number_two {
    padding: 15px 11px 15px 40px!important;
}
    .fieldset_2 .image,
.fieldset_1  .image {
    height: auto;
    max-width: 30%;
}
.fieldset_2  h2.fs-title,
.fieldset_1 h2.fs-title2{

    line-height: 17px;
    font-size: 16px;

}

.fieldset_2  h2.fs-title2 {
    line-height: 25px;
    font-size: 20px;
}



.fieldset_1  input#title-user{
    font-size: 20px!important;
    padding: 0;
     width: 100%; 
     padding: 27px;
     margin: auto;
}
.fieldset_1  input.next.action-button {
    margin: 25px!important;
    width: 78%!important;
    padding: 20px!important;

}
.box{
    width: 34%;
    height: 190px;
}
.fieldset_2 div#temp_2_box_2\ responsive {
    margin-left: 13%;
}
div#tem_3_box_9,
div#tem_3_box_7\ left1,
div#tem_3_box_3\ left1 {
    margin-left: 13%;
}
}






@media only screen and (max-width: 600px) {
	
	
	
	#progressbar li:after {
    content: '';
    width: 85%;
    height: 2px;
    background: #8f7676;
    position: absolute;
    left: 45%;
    top: 11px;
    z-index: -1;
}
	
	
	
	
#progressbar li:before {
    content: counter(step);
    counter-increment: step;
    width: 1.9em;
    height: 1.9em;
    border: 1px solid;
    font-weight: 600;
  padding-top: 9px;
    line-height: 0px; 
    display: block;
    font-size: 12px;
    color: #3b7ef4;
    background: white;
    border-radius: 51%;
    margin: 0 auto 10px auto;
}
	.span6{
		width:87%;
	}
	
	#myCheck{
		    width: 13% !important;
	}
	 .box h5{
    padding-bottom: 47px;
    margin-top: -76%;
    padding-top: 12px;
    transition: 0.5s all;
    font-size: 15px;
}
	
	

    .fieldset_5 input#number_two {
    font-size: 16px!important;
}


.fieldset_1 h2.fs-title{
font-size: 20px!important;
    padding-top: 16px!important;
}
.fieldset_6 .image,
.fieldset_5 .image,
.fieldset_4 .image,
.fieldset_3 .image,
.fieldset_2 .image,
.fieldset_1  .image {
    height: auto;
    max-width: 30%;
}
.fieldset_5 h2.fs-title2,
.fieldset_5 h2.fs-title2,
.fieldset_4  h2.fs-title2,
.fieldset_2  h2.fs-title,
.fieldset_1 h2.fs-title2{

    line-height: 17px;
    font-size: 16px;

}


.fieldset_2  h2.fs-title2 {
    line-height: 25px;
    font-size: 20px;
}

.fieldset_3  h2.fs-title2{
    line-height: 25px;
    font-size: 20px;
}



input.action-button{
    font-size:16px!important;
}

.fieldset_2 div#temp_2_box_2\ responsive {
    margin-left: 13%;
}

.fieldset_3 input#number_two,
.fieldset_2  #msform input,
.fieldset_2  input#number_two,
#msform textarea{
    font-size: 15px!important;
}


.fieldset_1  h2.fs-titlelast{
    font-size: 20px;
}

.fieldset_1  input#title-user{
    font-size: 20px!important;
    padding: 0;
     width: 100%; 
     padding: 19px;
  
}


.fieldset_1  input.next.action-button {
    margin: 25px!important;
    width: 78%!important;
    padding: 8px!important;
}



.fieldset_1  input#title-user {
    margin-bottom: 0;
}


.fieldset_2 .box{
    width: 34%;
    height: 165px;
}
.fieldset_3 .box{
    width: 34%;
    height: 152px;
}
.fieldset_4 .box{
    width: 34%;
    height: 150px;
}


.fieldset_5 .box {
    width: 34%;
    height: 111px;
}



#number_two {
    padding: 15px 0px 15px 0px!important;
}
div#temp_2_box {
    margin-left: 13%;

}

div#tem_3_box_9,
div#tem_3_box_7\ left1,
div#tem_3_box_3\ left1 {
    margin-left: 13%;
}

div#temp_2_box_2\ ress,
div#tem_4_box_3\ ress {
    margin-left: 13%;
}
div#tem_3_box_10 {
    margin-right: 0%;
}

input#phone-user {
    width: 100%;
}
input#zz-submit-email {
    width: unset;
}
}
#progressbar {
    rotate: 180deg;
 
}

#progressbar li{
    rotate: 180deg;
}
	
	.chk {
		opacity:0;
	}
</style>


<script>
  //jQuery time
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

$(".next").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	next_fs = $(this).parent().next();
	
	//activate next step on progressbar using the index of next_fs
	$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
	
	//show the next fieldset
	next_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale current_fs down to 80%
			scale = 1 - (1 - now) * 0.2;
			//2. bring next_fs from the right(50%)
			left = (now * 50)+"%";
			//3. increase opacity of next_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({
        'transform': 'scale('+scale+')'
      
      });
			next_fs.css({'left': left, 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".previous").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();
	
	//de-activate current step on progressbar
	$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
	
	//show the previous fieldset
	previous_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale previous_fs from 80% to 100%
			scale = 0.8 + (1 - now) * 0.2;
			//2. take current_fs to the right(50%) - from 0%
			left = ((1-now) * 50)+"%";
			//3. increase opacity of previous_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'left': left});
			previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
		}, 
		duration: 100, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".submit").click(function(){
	return false;
})



$(document).ready(function(){
    $('.action-button').attr('disabled',true);
    $('#title-user').keyup(function(){
        if($(this).val().length !=0)
            $('.action-button').attr('disabled', false);            
        else
            $('.action-button').attr('disabled',true);
    })
});


function IsEmpty() {
  if (document.forms['xcxcxc'].question.value === "") {
    alert("You must fill your phone Number");
    return false;
  }
  return true;
}

</script>


