jQuery(function($){
	
	
	// SEND Email
	$('#zz-submit-email').on('click',function(){
		
		var aData = {  
			'_ajax_nonce': ZZCE_var.nonce,
			'action': 'ZZCE_sendmail',
			'title_user': $("#title-user").val(),
			'phone_user': $("#phone-user").val(),
			'image_user': $("#img1").val(),
			'image_user_s2': $("#img2").val(),
			'image_user_s3': $("#img3").val(),
			'image_user_s4': $("#img4").val(),
			'image_user_s5': $("#img5").val(),
			'image_user_s6': $("#img6").val(),
			'image_user_s7': $("#img7").val(),
			'image_user_s8': $("#img8").val(),
			'image_user_s9': $("#img9").val(),
			'image_user_s10': $("#img10").val(),
			'image_user_s11': $("#img11").val(),
			'image_user_s12': $("#img12").val(),
			'image_user_s13': $("#img13").val(),
			'image_user_s14': $("#img14").val(),
			'image_user_s15': $("#img15").val(),
			'image_user_s16': $("#img16").val(),
			'image_user_s17': $("#img17").val(),
			'image_user_s18': $("#img18").val(),
			'image_user_s19': $("#img19").val(),
			'image_user_s20': $("#img20").val(),
			'image_user_s21': $("#img21").val(),
			'image_user_s22': $("#img22").val()
		};
	
		jQuery.ajax({
           url: ZZCE_var.ajax_url,
           type: "POST",
           cache: false,
           data: aData,
		   beforeSend: function() {
			   $("#zz-email-result").html('<div class="zz-process">Please waiting...</div>');
		   },
           success:function(response){
			   
			   $("#zz-email-result").html(response);
			}
        }); 
	});
});

let aliff=document.getElementById('image_1');
aliff.onclick=function(){
   let old_1=document.getElementById('old_1');
   old_1.setAttribute('id','img1'); 

}


let image_2=document.getElementById('image_2');
image_2.onclick=function(){
   let old_2=document.getElementById('old_2');
   old_2.setAttribute('id','img2'); 

}

let image_3=document.getElementById('image_3');
image_3.onclick=function(){
   let old_3=document.getElementById('old_3');
   old_3.setAttribute('id','img3'); 

}

let image_4=document.getElementById('image_4');
image_4.onclick=function(){
   let old_4=document.getElementById('old_4');
   old_4.setAttribute('id','img4'); 

}


let image_5=document.getElementById('image_5');
image_5.onclick=function(){
   let old_5=document.getElementById('old_5');
   old_5.setAttribute('id','img5'); 

}

let image_6=document.getElementById('image_6');
image_6.onclick=function(){
   let old_6=document.getElementById('old_6');
   old_6.setAttribute('id','img6'); 

}

let image_7=document.getElementById('image_7');
image_7.onclick=function(){
   let old_7=document.getElementById('old_7');
   old_7.setAttribute('id','img7'); 

}

let image_8=document.getElementById('image_8');
image_8.onclick=function(){
   let old_8=document.getElementById('old_8');
   old_8.setAttribute('id','img8'); 

}


let image_9=document.getElementById('image_9');
image_9.onclick=function(){
   let old_9=document.getElementById('old_9');
   old_9.setAttribute('id','img9'); 

}

let image_10=document.getElementById('image_10');
image_10.onclick=function(){
   let old_10=document.getElementById('old_10');
   old_10.setAttribute('id','img10'); 

}

let image_11=document.getElementById('image_11');
image_11.onclick=function(){
   let old_11=document.getElementById('old_11');
   old_11.setAttribute('id','img11'); 

}

let image_12=document.getElementById('image_12');
image_12.onclick=function(){
   let old_12=document.getElementById('old_12');
   old_12.setAttribute('id','img12'); 

}


let image_13=document.getElementById('image_13');
image_13.onclick=function(){
   let old_13=document.getElementById('old_13');
   old_13.setAttribute('id','img13'); 

}

let image_14=document.getElementById('image_14');
image_14.onclick=function(){
   let old_14=document.getElementById('old_14');
   old_14.setAttribute('id','img14'); 

}


let image_15=document.getElementById('image_15');
image_15.onclick=function(){
   let old_15=document.getElementById('old_15');
   old_15.setAttribute('id','img15'); 

}

let image_16=document.getElementById('image_16');
image_16.onclick=function(){
   let old_16=document.getElementById('old_16');
   old_16.setAttribute('id','img16'); 

}

let image_17=document.getElementById('image_17');
image_17.onclick=function(){
   let old_17=document.getElementById('old_17');
   old_17.setAttribute('id','img17'); 

}

let image_18=document.getElementById('image_18');
image_18.onclick=function(){
   let old_18=document.getElementById('old_18');
   old_18.setAttribute('id','img18'); 

}

let image_19=document.getElementById('image_19');
image_19.onclick=function(){
   let old_19=document.getElementById('old_19');
   old_19.setAttribute('id','img19'); 

}

let image_20=document.getElementById('image_20');
image_20.onclick=function(){
   let old_20=document.getElementById('old_20');
   old_20.setAttribute('id','img20'); 

}
let image_21=document.getElementById('image_21');
image_21.onclick=function(){
   let old_21=document.getElementById('old_21');
   old_21.setAttribute('id','img21'); 

}

let image_22=document.getElementById('image_22');
image_22.onclick=function(){
   let old_22=document.getElementById('old_22');
   old_22.setAttribute('id','img22'); 

}
