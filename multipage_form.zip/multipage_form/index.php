<?php
//silence is best