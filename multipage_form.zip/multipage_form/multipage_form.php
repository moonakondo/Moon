<?php
/*
 * Plugin Name: Multipage form
 */
 //File link
include_once("action.php");
include_once("add_data.php");


define("CUSTOM_CONS",plugin_dir_url(__FILE__ ));


echo CUSTOM_CONS;

function js_css_link(){
  wp_enqueue_style( "mleod-css",CUSTOM_CONS."css/style.css",array(), "1.0.0","all");
  wp_enqueue_script("ssss",CUSTOM_CONS."js/index.js",array("jquery"), "1.0.0","all");

}

add_action("wp_enqueue_scripts","js_css_link");

//Codr for admin menu

add_action( "admin_menu", "main_menu" );
function main_menu(){
    add_menu_page( "Multiple Form Data", "Multiple Form Data","manage_options", "mulple-form-data", "main_callback", "dashicons-admin-users",1 );

    add_submenu_page("mulple-form-data","View","Multiple Form Data","manage_options","mulple-form-data","main_callback");

}

function main_callback(){

    global $wpdb;
    $main_prefix=$wpdb->prefix;//wp_
    $alifs=$wpdb->get_results("SELECT* FROM {$main_prefix}multi_form_table" ,ARRAY_A);

?>


<div class="panel panel-primary  col-md-12" style="margin-top:5%;border:none">
      <div class="panel-heading"><h2>Form Data</h2></div>
      <div class="panel-body">

  <table class="table">
    <thead>
      <tr>
      <th>First Name</th>
        <th>Last name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Phone</th>
        <th>Address</th>
      </tr>
    </thead>
    <tbody>
 <?php
if(count($alifs)>0){
  foreach($alifs as $alif){
?>
  <tr>
    <td><?php echo $alif['fname'] ?></td>
    <td><?php echo $alif['lName'] ?></td>
    <td><?php echo $alif['email'] ?></td>
    <td><?php echo $alif['password'] ?></td>
    <td><?php echo $alif['phone'] ?></td>
    <td><?php echo $alif['address'] ?></td>
  </tr>

<?php
  }
}

?>
    </tbody>
  </table>
</div>
</div>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


<?php
}

register_activation_hook( (__FILE__), "database_creation");

function database_creation(){
//DATABASE CREATUIN 

global $wpdb;

$data_prefix= $wpdb->prefix;

$sql="CREATE TABLE {$data_prefix}multi_form_table (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `email` varchar(50) NOT NULL,
    `password` varchar(50) NOT NULL,
    `fname` varchar(100) NOT NULL,
    `lName` varchar(100) NOT NULL,
    `phone` varchar(100) NOT NULL,
    `address` text NOT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 
  ";

include_once ABSPATH."wp-admin/includes/upgrade.php";

dbDelta($sql);

}




